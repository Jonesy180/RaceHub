const SEED={"cars":[{"id":"abarth-595-esseesse-1968","make":"Abarth","model":"595 Esseesse","year":"1968","name":"Abarth 595 Esseesse 1968"},{"id":"acura-integra-type-r-2001","make":"Acura","model":"Integra Type R","year":"2001","name":"Acura Integra Type R 2001"},{"id":"acura-nsx-2017","make":"Acura","model":"NSX","year":"2017","name":"Acura NSX 2017"},{"id":"acura-rsx-type-s-2002","make":"Acura","model":"RSX Type S","year":"2002","name":"Acura RSX Type S 2002"},{"id":"alfa-romeo-33-stradale-1968","make":"Alfa Romeo","model":"33 Stradale","year":"1968","name":"Alfa Romeo 33 Stradale 1968"},{"id":"alfa-romeo-giulia-quadrifoglio-2017","make":"Alfa Romeo","model":"Giulia Quadrifoglio","year":"2017","name":"Alfa Romeo Giulia Quadrifoglio 2017"},{"id":"alfa-romeo-giulia-sprint-gta-stradale-1965","make":"Alfa Romeo","model":"Giulia Sprint GTA Stradale","year":"1965","name":"Alfa Romeo Giulia Sprint GTA Stradale 1965"},{"id":"alfa-romeo-giulia-tz2-1965","make":"Alfa Romeo","model":"Giulia TZ2","year":"1965","name":"Alfa Romeo Giulia TZ2 1965"},{"id":"alpine-a110-1600s-1973","make":"Alpine","model":"A110 1600s","year":"1973","name":"Alpine A110 1600s 1973"},{"id":"alpine-a110-2017","make":"Alpine","model":"A110","year":"2017","name":"Alpine A110 2017"},{"id":"alumicraft-6165-trick-truck-2022","make":"Alumicraft","model":"#6165 Trick Truck","year":"2022","name":"Alumicraft #6165 Trick Truck 2022"},{"id":"alumicraft-class-10-race-car-2015","make":"Alumicraft","model":"Class 10 Race Car","year":"2015","name":"Alumicraft Class 10 Race Car 2015"},{"id":"amc-gremlin-x-1973","make":"AMC","model":"Gremlin X","year":"1973","name":"AMC Gremlin X 1973"},{"id":"amg-transport-dynamics-m125-warthog-cst-2554","make":"AMG Transport Dynamics","model":"M125 Warthog CST","year":"2554","name":"AMG Transport Dynamics M125 Warthog CST 2554"},{"id":"apollo-intensa-emozione-2018","make":"Apollo","model":"Intensa Emozione","year":"2018","name":"Apollo Intensa Emozione 2018"},{"id":"apollo-intense-emozione-wp-2018","make":"Apollo","model":"Intense Emozione WP","year":"2018","name":"Apollo Intense Emozione WP 2018"},{"id":"ariel-atom-500-v8-2013","make":"Ariel","model":"Atom 500 V8","year":"2013","name":"Ariel Atom 500 V8 2013"},{"id":"ariel-nomad-2016","make":"Ariel","model":"Nomad","year":"2016","name":"Ariel Nomad 2016"},{"id":"aston-martin-db11-2017","make":"Aston Martin","model":"DB11","year":"2017","name":"Aston Martin DB11 2017"},{"id":"aston-martin-db5-1964","make":"Aston Martin","model":"DB5","year":"1964","name":"Aston Martin DB5 1964"},{"id":"aston-martin-dbr1-1958","make":"Aston Martin","model":"DBR1","year":"1958","name":"Aston Martin DBR1 1958"},{"id":"aston-martin-dbs-superleggera-2019","make":"Aston Martin","model":"DBS Superleggera","year":"2019","name":"Aston Martin DBS Superleggera 2019"},{"id":"aston-martin-dbx-2021","make":"Aston Martin","model":"DBX","year":"2021","name":"Aston Martin DBX 2021"},{"id":"aston-martin-one-77-2010","make":"Aston Martin","model":"One-77","year":"2010","name":"Aston Martin One-77 2010"},{"id":"aston-martin-v12-vantage-s-2013","make":"Aston Martin","model":"V12 Vantage S","year":"2013","name":"Aston Martin V12 Vantage S 2013"},{"id":"aston-martin-valhalla-concept-car-2019","make":"Aston Martin","model":"Valhalla Concept Car","year":"2019","name":"Aston Martin Valhalla Concept Car 2019"},{"id":"aston-martin-valkyrie-amr-pro-2022","make":"Aston Martin","model":"Valkyrie AMR Pro","year":"2022","name":"Aston Martin Valkyrie AMR Pro 2022"},{"id":"aston-martin-vantage-2019","make":"Aston Martin","model":"Vantage","year":"2019","name":"Aston Martin Vantage 2019"},{"id":"aston-martin-vantage-gt12-2015","make":"Aston Martin","model":"Vantage GT12","year":"2015","name":"Aston Martin Vantage GT12 2015"},{"id":"aston-martin-vulcan-amr-pro-2017","make":"Aston Martin","model":"Vulcan AMR Pro","year":"2017","name":"Aston Martin Vulcan AMR Pro 2017"},{"id":"audi-2-audi-quattro-s1-1986","make":"Audi","model":"#2 Audi Quattro S1","year":"1986","name":"Audi #2 Audi Quattro S1 1986"},{"id":"audi-avant-rs2-1995","make":"Audi","model":"Avant RS2","year":"1995","name":"Audi Avant RS2 1995"},{"id":"audi-r8-coupe-v10-plus-5-2-fsi-quattro-2013","make":"Audi","model":"R8 Coupe V10 Plus 5.2 FSI Quattro","year":"2013","name":"Audi R8 Coupe V10 Plus 5.2 FSI Quattro 2013"},{"id":"audi-r8-v10-plus-2016","make":"Audi","model":"R8 V10 Plus","year":"2016","name":"Audi R8 V10 Plus 2016"},{"id":"audi-rs-3-sedan-2020","make":"Audi","model":"RS 3 Sedan","year":"2020","name":"Audi RS 3 Sedan 2020"},{"id":"audi-rs-3-sportback-2011","make":"Audi","model":"RS 3 Sportback","year":"2011","name":"Audi RS 3 Sportback 2011"},{"id":"audi-rs-4-2006","make":"Audi","model":"RS 4","year":"2006","name":"Audi RS 4 2006"},{"id":"audi-rs-4-avant-2001","make":"Audi","model":"RS 4 Avant","year":"2001","name":"Audi RS 4 Avant 2001"},{"id":"audi-rs-4-avant-2013","make":"Audi","model":"RS 4 Avant","year":"2013","name":"Audi RS 4 Avant 2013"},{"id":"audi-rs-5-coupe-2011","make":"Audi","model":"RS 5 Coupe","year":"2011","name":"Audi RS 5 Coupe 2011"},{"id":"audi-rs-5-coupe-2018","make":"Audi","model":"RS 5 Coupe","year":"2018","name":"Audi RS 5 Coupe 2018"},{"id":"audi-rs-6-2003","make":"Audi","model":"RS 6","year":"2003","name":"Audi RS 6 2003"},{"id":"audi-rs-6-2009","make":"Audi","model":"RS 6","year":"2009","name":"Audi RS 6 2009"},{"id":"audi-rs-6-avant-2015","make":"Audi","model":"RS 6 Avant","year":"2015","name":"Audi RS 6 Avant 2015"},{"id":"audi-rs-7-sportback-2013","make":"Audi","model":"RS 7 Sportback","year":"2013","name":"Audi RS 7 Sportback 2013"},{"id":"audi-s1-2015","make":"Audi","model":"S1","year":"2015","name":"Audi S1 2015"},{"id":"audi-sport-quattro-1983","make":"Audi","model":"Sport Quattro","year":"1983","name":"Audi Sport Quattro 1983"},{"id":"audi-tt-rs-2018","make":"Audi","model":"TT RS","year":"2018","name":"Audi TT RS 2018"},{"id":"audi-tt-rs-coupe-2010","make":"Audi","model":"TT RS Coupe","year":"2010","name":"Audi TT RS Coupe 2010"},{"id":"audi-tts-coupe-2015","make":"Audi","model":"TTS Coupe","year":"2015","name":"Audi TTS Coupe 2015"},{"id":"austin-healey-sprite-mk1-1958","make":"Austin-Healey","model":"Sprite MK1","year":"1958","name":"Austin-Healey Sprite MK1 1958"},{"id":"auto-union-type-d-1939","make":"Auto Union","model":"Type D","year":"1939","name":"Auto Union Type D 1939"},{"id":"automobili-pinnfarina-battista-2010","make":"Automobili","model":"Pinnfarina Battista","year":"2010","name":"Automobili Pinnfarina Battista 2010"},{"id":"autozam-az-1-1993","make":"Autozam","model":"AZ-1","year":"1993","name":"Autozam AZ-1 1993"},{"id":"bac-mono-2014","make":"BAC","model":"Mono","year":"2014","name":"BAC Mono 2014"},{"id":"bentley-8-litre-1930","make":"Bentley","model":"8 Litre","year":"1930","name":"Bentley 8 Litre 1930"},{"id":"bentley-bentayga-2016","make":"Bentley","model":"Bentayga","year":"2016","name":"Bentley Bentayga 2016"},{"id":"bentley-blower-4-1-2-litre-supercharged-1930","make":"Bentley","model":"Blower 4-1/2 Litre Supercharged","year":"1930","name":"Bentley Blower 4-1/2 Litre Supercharged 1930"},{"id":"bentley-continental-gt-convertible-2021","make":"Bentley","model":"Continental GT Convertible","year":"2021","name":"Bentley Continental GT Convertible 2021"},{"id":"bentley-continental-supersports-2017","make":"Bentley","model":"Continental Supersports","year":"2017","name":"Bentley Continental Supersports 2017"},{"id":"bentley-flying-spur-2021","make":"Bentley","model":"Flying Spur","year":"2021","name":"Bentley Flying Spur 2021"},{"id":"bentley-turbo-r-1991","make":"Bentley","model":"Turbo R","year":"1991","name":"Bentley Turbo R 1991"},{"id":"bmw-1-bmw-m-motorsport-m8-gte-2018","make":"BMW","model":"#1 BMW M Motorsport M8 GTE","year":"2018","name":"BMW #1 BMW M Motorsport M8 GTE 2018"},{"id":"bmw-1-series-m-coupe-2011","make":"BMW","model":"1 Series M Coupe","year":"2011","name":"BMW 1 Series M Coupe 2011"},{"id":"bmw-2002-turbo-1973","make":"BMW","model":"2002 Turbo","year":"1973","name":"BMW 2002 Turbo 1973"},{"id":"bmw-i8-2015","make":"BMW","model":"I8","year":"2015","name":"BMW I8 2015"},{"id":"bmw-isetta-300-export-1957","make":"BMW","model":"Isetta 300 Export","year":"1957","name":"BMW Isetta 300 Export 1957"},{"id":"bmw-m1-1981","make":"BMW","model":"M1","year":"1981","name":"BMW M1 1981"},{"id":"bmw-m2-coupe-2016","make":"BMW","model":"M2 Coupe","year":"2016","name":"BMW M2 Coupe 2016"},{"id":"bmw-m3-1991","make":"BMW","model":"M3","year":"1991","name":"BMW M3 1991"},{"id":"bmw-m3-1997","make":"BMW","model":"M3","year":"1997","name":"BMW M3 1997"},{"id":"bmw-m3-2005","make":"BMW","model":"M3","year":"2005","name":"BMW M3 2005"},{"id":"bmw-m3-2008","make":"BMW","model":"M3","year":"2008","name":"BMW M3 2008"},{"id":"bmw-m3-gtr-2002","make":"BMW","model":"M3-GTR","year":"2002","name":"BMW M3-GTR 2002"},{"id":"bmw-m4-coupe-2014","make":"BMW","model":"M4 Coupe","year":"2014","name":"BMW M4 Coupe 2014"},{"id":"bmw-m4-gts-2016","make":"BMW","model":"M4 GTS","year":"2016","name":"BMW M4 GTS 2016"},{"id":"bmw-m5-1988","make":"BMW","model":"M5","year":"1988","name":"BMW M5 1988"},{"id":"bmw-m5-1995","make":"BMW","model":"M5","year":"1995","name":"BMW M5 1995"},{"id":"bmw-m5-2003","make":"BMW","model":"M5","year":"2003","name":"BMW M5 2003"},{"id":"bmw-m5-2009","make":"BMW","model":"M5","year":"2009","name":"BMW M5 2009"},{"id":"bmw-m5-2012","make":"BMW","model":"M5","year":"2012","name":"BMW M5 2012"},{"id":"bmw-m5-2018","make":"BMW","model":"M5","year":"2018","name":"BMW M5 2018"},{"id":"bmw-m6-coupe-2013","make":"BMW","model":"M6 Coupe","year":"2013","name":"BMW M6 Coupe 2013"},{"id":"bmw-m8-competition-coupe-2020","make":"BMW","model":"M8 Competition Coupe","year":"2020","name":"BMW M8 Competition Coupe 2020"},{"id":"bmw-x5-m-2011","make":"BMW","model":"X5 M","year":"2011","name":"BMW X5 M 2011"},{"id":"bmw-x5-m-forza-edition-2011","make":"BMW","model":"X5 M Forza Edition","year":"2011","name":"BMW X5 M Forza Edition 2011"},{"id":"bmw-x6-m-2015","make":"BMW","model":"X6 M","year":"2015","name":"BMW X6 M 2015"},{"id":"bmw-z3-m-coupe-2002","make":"BMW","model":"Z3 M Coupe","year":"2002","name":"BMW Z3 M Coupe 2002"},{"id":"bmw-z4-m-coupe-2008","make":"BMW","model":"Z4 M Coupe","year":"2008","name":"BMW Z4 M Coupe 2008"},{"id":"bmw-z4-roadster-2019","make":"BMW","model":"Z4 Roadster","year":"2019","name":"BMW Z4 Roadster 2019"},{"id":"bugatti-chiron-2018","make":"Bugatti","model":"Chiron","year":"2018","name":"Bugatti Chiron 2018"},{"id":"bugatti-divo-2019","make":"Bugatti","model":"Divo","year":"2019","name":"Bugatti Divo 2019"},{"id":"bugatti-eb110-super-sport-1992","make":"Bugatti","model":"EB110 Super Sport","year":"1992","name":"Bugatti EB110 Super Sport 1992"},{"id":"bugatti-type-35-c-1926","make":"Bugatti","model":"Type 35 C","year":"1926","name":"Bugatti Type 35 C 1926"},{"id":"bugatti-veyron-super-sport-2011","make":"Bugatti","model":"Veyron Super Sport","year":"2011","name":"Bugatti Veyron Super Sport 2011"},{"id":"buick-gsx-1970","make":"Buick","model":"GSX","year":"1970","name":"Buick GSX 1970"},{"id":"buick-regal-gnx-1987","make":"Buick","model":"Regal GNX","year":"1987","name":"Buick Regal GNX 1987"},{"id":"cadillac-3-cadillac-racing-ats-v-r-2015","make":"Cadillac","model":"#3 Cadillac Racing ATS-V.R","year":"2015","name":"Cadillac #3 Cadillac Racing ATS-V.R 2015"},{"id":"cadillac-ats-v-2016","make":"Cadillac","model":"ATS-V","year":"2016","name":"Cadillac ATS-V 2016"},{"id":"cadillac-cts-v-sedan-2016","make":"Cadillac","model":"CTS-V Sedan","year":"2016","name":"Cadillac CTS-V Sedan 2016"},{"id":"can-am-maverick-x-rs-turbo-2018","make":"Can-Am","model":"Maverick X RS Turbo","year":"2018","name":"Can-Am Maverick X RS Turbo 2018"},{"id":"casey-currie-motorsports-no-4402-ultra-4-trophy-jeep-2019","make":"Casey Currie","model":"Motorsports No.4402 Ultra 4 Trophy Jeep","year":"2019","name":"Casey Currie Motorsports No.4402 Ultra 4 Trophy Jeep 2019"},{"id":"caterham-superlight-r500-2013","make":"Caterham","model":"Superlight R500","year":"2013","name":"Caterham Superlight R500 2013"},{"id":"chevrolet-3-corvette-racing-c8-r-2020","make":"Chevrolet","model":"#3 Corvette Racing C8.R","year":"2020","name":"Chevrolet #3 Corvette Racing C8.R 2020"},{"id":"chevrolet-150-utility-sedan-1955","make":"Chevrolet","model":"150 Utility Sedan","year":"1955","name":"Chevrolet 150 Utility Sedan 1955"},{"id":"chevrolet-barbie-movie-corvette-ev-1956","make":"Chevrolet","model":"Barbie Movie Corvette EV","year":"1956","name":"Chevrolet Barbie Movie Corvette EV 1956"},{"id":"chevrolet-bel-air-1957","make":"Chevrolet","model":"Bel Air","year":"1957","name":"Chevrolet Bel Air 1957"},{"id":"chevrolet-camaro-z-28-2015","make":"Chevrolet","model":"Camaro Z/28","year":"2015","name":"Chevrolet Camaro Z/28 2015"},{"id":"chevrolet-camaro-z28-1970","make":"Chevrolet","model":"Camaro Z28","year":"1970","name":"Chevrolet Camaro Z28 1970"},{"id":"chevrolet-camaro-z28-1979","make":"Chevrolet","model":"Camaro Z28","year":"1979","name":"Chevrolet Camaro Z28 1979"},{"id":"chevrolet-camaro-zl-1-1le-2018","make":"Chevrolet","model":"Camaro ZL 1 1LE","year":"2018","name":"Chevrolet Camaro ZL 1 1LE 2018"},{"id":"chevrolet-camaro-zl-1-2017","make":"Chevrolet","model":"Camaro ZL 1","year":"2017","name":"Chevrolet Camaro ZL 1 2017"},{"id":"chevrolet-camero-super-sport-coupe-1969","make":"Chevrolet","model":"Camero Super Sport Coupe","year":"1969","name":"Chevrolet Camero Super Sport Coupe 1969"},{"id":"chevrolet-chevelle-super-sport-454-1970","make":"Chevrolet","model":"Chevelle Super Sport 454","year":"1970","name":"Chevrolet Chevelle Super Sport 454 1970"},{"id":"chevrolet-colorado-zr2-2017","make":"Chevrolet","model":"Colorado ZR2","year":"2017","name":"Chevrolet Colorado ZR2 2017"},{"id":"chevrolet-corvette-1953","make":"Chevrolet","model":"Corvette","year":"1953","name":"Chevrolet Corvette 1953"},{"id":"chevrolet-corvette-1960","make":"Chevrolet","model":"Corvette","year":"1960","name":"Chevrolet Corvette 1960"},{"id":"chevrolet-corvette-e-ray-2024","make":"Chevrolet","model":"Corvette E-Ray","year":"2024","name":"Chevrolet Corvette E-Ray 2024"},{"id":"chevrolet-corvette-forza-edition-1953","make":"Chevrolet","model":"Corvette Forza Edition","year":"1953","name":"Chevrolet Corvette Forza Edition 1953"},{"id":"chevrolet-corvette-stingray-427-1967","make":"Chevrolet","model":"Corvette Stingray 427","year":"1967","name":"Chevrolet Corvette Stingray 427 1967"},{"id":"chevrolet-corvette-stingray-coupe-2020","make":"Chevrolet","model":"Corvette Stingray Coupe","year":"2020","name":"Chevrolet Corvette Stingray Coupe 2020"},{"id":"chevrolet-corvette-z06-2002","make":"Chevrolet","model":"Corvette Z06","year":"2002","name":"Chevrolet Corvette Z06 2002"},{"id":"chevrolet-corvette-z06-2015","make":"Chevrolet","model":"Corvette Z06","year":"2015","name":"Chevrolet Corvette Z06 2015"},{"id":"chevrolet-corvette-zr-1-1970","make":"Chevrolet","model":"Corvette ZR-1","year":"1970","name":"Chevrolet Corvette ZR-1 1970"},{"id":"chevrolet-corvette-zr-1-1995","make":"Chevrolet","model":"Corvette ZR-1","year":"1995","name":"Chevrolet Corvette ZR-1 1995"},{"id":"chevrolet-corvette-zr1-2009","make":"Chevrolet","model":"Corvette ZR1","year":"2009","name":"Chevrolet Corvette ZR1 2009"},{"id":"chevrolet-el-camino-super-sport-454-1970","make":"Chevrolet","model":"El Camino Super Sport 454","year":"1970","name":"Chevrolet El Camino Super Sport 454 1970"},{"id":"chevrolet-impala-super-sport-1996","make":"Chevrolet","model":"Impala Super Sport","year":"1996","name":"Chevrolet Impala Super Sport 1996"},{"id":"chevrolet-impala-super-sport-409-1964","make":"Chevrolet","model":"Impala Super Sport 409","year":"1964","name":"Chevrolet Impala Super Sport 409 1964"},{"id":"chevrolet-monte-carlo-super-sport-1988","make":"Chevrolet","model":"Monte Carlo Super Sport","year":"1988","name":"Chevrolet Monte Carlo Super Sport 1988"},{"id":"chevrolet-nova-super-sport-396-1969","make":"Chevrolet","model":"Nova Super Sport 396","year":"1969","name":"Chevrolet Nova Super Sport 396 1969"},{"id":"chevrolet-silverado-lt-trail-boss-2020","make":"Chevrolet","model":"Silverado LT Trail Boss","year":"2020","name":"Chevrolet Silverado LT Trail Boss 2020"},{"id":"chevrolet-colorado-zr2-2017","make":"Chevrolet","model":"Colorado ZR2","year":"2017","name":"Chevrolet Colorado ZR2 2017"},{"id":"chevrolet-corvette-stingray-coupe-2020","make":"Chevrolet","model":"Corvette Stingray Coupe","year":"2020","name":"Chevrolet Corvette Stingray Coupe 2020"},{"id":"chevrolet-impala-super-sport-409-1964","make":"Chevrolet","model":"Impala Super Sport 409","year":"1964","name":"Chevrolet Impala Super Sport 409 1964"},{"id":"cupra-formentor-vz5-2022","make":"Cupra","model":"Formentor VZ5","year":"2022","name":"Cupra Formentor VZ5 2022"},{"id":"cupra-tavascan-concept-2022","make":"Cupra","model":"Tavascan Concept","year":"2022","name":"Cupra Tavascan Concept 2022"},{"id":"cupra-urbanrebel-concept-2022","make":"Cupra","model":"Urbanrebel Concept","year":"2022","name":"Cupra Urbanrebel Concept 2022"},{"id":"czinger-21c-2024","make":"Czinger","model":"21C","year":"2024","name":"Czinger 21C 2024"},{"id":"datsun-s10-1970","make":"Datsun","model":"S10","year":"1970","name":"Datsun S10 1970"},{"id":"deberti-chevrolet-silverado-1500-drift-truck-2018","make":"Deberti","model":"Chevrolet Silverado 1500 Drift Truck","year":"2018","name":"Deberti Chevrolet Silverado 1500 Drift Truck 2018"},{"id":"deberti-f-150-prerunner-2018","make":"Deberti","model":"F-150 Prerunner","year":"2018","name":"Deberti F-150 Prerunner 2018"},{"id":"deberti-ford-econoline-shop-rod-1961","make":"Deberti","model":"Ford Econoline 'Shop Rod'","year":"1961","name":"Deberti Ford Econoline 'Shop Rod' 1961"},{"id":"deberti-toyota-tacoma-trd-performance-truck-2019","make":"Deberti","model":"Toyota Tacoma TRD Performance Truck","year":"2019","name":"Deberti Toyota Tacoma TRD Performance Truck 2019"},{"id":"dodge-challenger-r-t-1970","make":"Dodge","model":"Challenger R/T","year":"1970","name":"Dodge Challenger R/T 1970"},{"id":"dodge-challenger-srt-demon-2018","make":"Dodge","model":"Challenger SRT Demon","year":"2018","name":"Dodge Challenger SRT Demon 2018"},{"id":"dodge-challenger-srt-hellcat-2015","make":"Dodge","model":"Challenger SRT Hellcat","year":"2015","name":"Dodge Challenger SRT Hellcat 2015"},{"id":"dodge-charger-r-t-1969","make":"Dodge","model":"Charger R/T","year":"1969","name":"Dodge Charger R/T 1969"},{"id":"dodge-charger-r-t-forza-edition-1969","make":"Dodge","model":"Charger R/T Forza Edition","year":"1969","name":"Dodge Charger R/T Forza Edition 1969"},{"id":"dodge-charger-srt-hellcat-2015","make":"Dodge","model":"Charger SRT Hellcat","year":"2015","name":"Dodge Charger SRT Hellcat 2015"},{"id":"dodge-dart-hemi-super-stock-1968","make":"Dodge","model":"Dart Hemi Super Stock","year":"1968","name":"Dodge Dart Hemi Super Stock 1968"},{"id":"dodge-durango-srt-2018","make":"Dodge","model":"Durango SRT","year":"2018","name":"Dodge Durango SRT 2018"},{"id":"dodge-magnum-srt-8-2008","make":"Dodge","model":"Magnum SRT-8","year":"2008","name":"Dodge Magnum SRT-8 2008"},{"id":"dodge-srt-viper-anniversary-edition-2013","make":"Dodge","model":"SRT Viper Anniversary Edition","year":"2013","name":"Dodge SRT Viper Anniversary Edition 2013"},{"id":"dodge-srt-viper-gts-2013","make":"Dodge","model":"SRT Viper GTS","year":"2013","name":"Dodge SRT Viper GTS 2013"},{"id":"dodge-viper-acr-2016","make":"Dodge","model":"Viper ACR","year":"2016","name":"Dodge Viper ACR 2016"},{"id":"dodge-viper-gts-acr-1999","make":"Dodge","model":"Viper GTS ACR","year":"1999","name":"Dodge Viper GTS ACR 1999"},{"id":"dodge-viper-srt10-acr-2008","make":"Dodge","model":"Viper SRT10 ACR","year":"2008","name":"Dodge Viper SRT10 ACR 2008"},{"id":"elemental-rp1-2019","make":"Elemental","model":"RP1","year":"2019","name":"Elemental RP1 2019"},{"id":"exomotive-exocet-off-road-2018","make":"Exomotive","model":"Exocet Off-Road","year":"2018","name":"Exomotive Exocet Off-Road 2018"},{"id":"exomotive-exocet-off-road-forza-edition-2018","make":"Exomotive","model":"Exocet Off-Road Forza Edition","year":"2018","name":"Exomotive Exocet Off-Road Forza Edition 2018"},{"id":"extreme-e-no-99-chip-ganassi-racing-gmc-hummer-ev-2022","make":"Extreme E","model":"No.99 Chip Ganassi Racing GMC Hummer EV","year":"2022","name":"Extreme E No.99 Chip Ganassi Racing GMC Hummer EV 2022"},{"id":"fast-and-furious-chevrolet-impala-super-sport-fast-x-1966","make":"Fast","model":"And Furious Chevrolet Impala Super Sport 'Fast X'","year":"1966","name":"Fast And Furious Chevrolet Impala Super Sport 'Fast X' 1966"},{"id":"fast-and-furious-datsun-240z-fast-x-1973","make":"Fast","model":"And Furious Datsun 240Z 'Fast X'","year":"1973","name":"Fast And Furious Datsun 240Z 'Fast X' 1973"},{"id":"fast-and-furious-dodge-charger-srt-hellcat-redeye-widebody-fast-x-2022","make":"Fast","model":"And Furious Dodge Charger SRT Hellcat Redeye Widebody 'Fast X'","year":"2022","name":"Fast And Furious Dodge Charger SRT Hellcat Redeye Widebody 'Fast X' 2022"},{"id":"fast-and-furious-dosge-charger-fast-x-1970","make":"Fast","model":"And Furious Dosge Charger 'Fast X'","year":"1970","name":"Fast And Furious Dosge Charger 'Fast X' 1970"},{"id":"fast-and-furious-flip-car-2-0-fast-x-2022","make":"Fast","model":"And Furious Flip Car 2.0 'Fast X'","year":"2022","name":"Fast And Furious Flip Car 2.0 'Fast X' 2022"},{"id":"ferrari-24-ferrari-spa-330-p4-1967","make":"Ferrari","model":"#24 Ferrari Spa 330 P4","year":"1967","name":"Ferrari #24 Ferrari Spa 330 P4 1967"},{"id":"ferrari-62-risi-competizione-488-gt3-2019","make":"Ferrari","model":"#62 Risi Competizione 488 GT3","year":"2019","name":"Ferrari #62 Risi Competizione 488 GT3 2019"},{"id":"ferrari-250-california-1957","make":"Ferrari","model":"250 California","year":"1957","name":"Ferrari 250 California 1957"},{"id":"ferrari-250-gt-berlinetta-lusso-1962","make":"Ferrari","model":"250 GT Berlinetta Lusso","year":"1962","name":"Ferrari 250 GT Berlinetta Lusso 1962"},{"id":"ferrari-250-gto-1962","make":"Ferrari","model":"250 GTO","year":"1962","name":"Ferrari 250 GTO 1962"},{"id":"ferrari-250-testa-rossa-1957","make":"Ferrari","model":"250 Testa Rossa","year":"1957","name":"Ferrari 250 Testa Rossa 1957"},{"id":"ferrari-296-gtb-2022","make":"Ferrari","model":"296 GTB","year":"2022","name":"Ferrari 296 GTB 2022"},{"id":"ferrari-360-challenge-stradale-2003","make":"Ferrari","model":"360 Challenge Stradale","year":"2003","name":"Ferrari 360 Challenge Stradale 2003"},{"id":"ferrari-365-gtb-4-1968","make":"Ferrari","model":"365 GTB/4","year":"1968","name":"Ferrari 365 GTB/4 1968"},{"id":"ferrari-430-scuderia-2017","make":"Ferrari","model":"430 Scuderia","year":"2017","name":"Ferrari 430 Scuderia 2017"},{"id":"ferrari-458-italia-2009","make":"Ferrari","model":"458 Italia","year":"2009","name":"Ferrari 458 Italia 2009"},{"id":"ferrari-458-speciale-2013","make":"Ferrari","model":"458 Speciale","year":"2013","name":"Ferrari 458 Speciale 2013"},{"id":"ferrari-488-gtb-2015","make":"Ferrari","model":"488 GTB","year":"2015","name":"Ferrari 488 GTB 2015"},{"id":"ferrari-488-pista-2019","make":"Ferrari","model":"488 Pista","year":"2019","name":"Ferrari 488 Pista 2019"},{"id":"ferrari-512-s-1970","make":"Ferrari","model":"512 S","year":"1970","name":"Ferrari 512 S 1970"},{"id":"ferrari-599xx-2010","make":"Ferrari","model":"599XX","year":"2010","name":"Ferrari 599XX 2010"},{"id":"ferrari-812-superfast-2017","make":"Ferrari","model":"812 Superfast","year":"2017","name":"Ferrari 812 Superfast 2017"},{"id":"ferrari-dino-246-gt-1969","make":"Ferrari","model":"Dino 246 GT","year":"1969","name":"Ferrari Dino 246 GT 1969"},{"id":"ferrari-f12tdf-2015","make":"Ferrari","model":"F12TDF","year":"2015","name":"Ferrari F12TDF 2015"},{"id":"ferrari-f355-berlinetta-1994","make":"Ferrari","model":"F355 Berlinetta","year":"1994","name":"Ferrari F355 Berlinetta 1994"},{"id":"ferrari-f40-1987","make":"Ferrari","model":"F40","year":"1987","name":"Ferrari F40 1987"},{"id":"ferrari-f40-competizione-1989","make":"Ferrari","model":"F40 Competizione","year":"1989","name":"Ferrari F40 Competizione 1989"},{"id":"ferrari-f50-1995","make":"Ferrari","model":"F50","year":"1995","name":"Ferrari F50 1995"},{"id":"ferrari-f50-gt-1996","make":"Ferrari","model":"F50 GT","year":"1996","name":"Ferrari F50 GT 1996"},{"id":"ferrari-fxx-2005","make":"Ferrari","model":"FXX","year":"2005","name":"Ferrari FXX 2005"},{"id":"ferrari-fxx-k-evo-2018","make":"Ferrari","model":"FXX-K Evo","year":"2018","name":"Ferrari FXX-K Evo 2018"},{"id":"ferrari-gtc4lusso-2017","make":"Ferrari","model":"GTC4Lusso","year":"2017","name":"Ferrari GTC4Lusso 2017"},{"id":"ferrari-j50-2017","make":"Ferrari","model":"J50","year":"2017","name":"Ferrari J50 2017"},{"id":"ferrari-laferrari-2013","make":"Ferrari","model":"LaFerrari","year":"2013","name":"Ferrari LaFerrari 2013"},{"id":"ferrari-monza-sp2-2019","make":"Ferrari","model":"Monza SP2","year":"2019","name":"Ferrari Monza SP2 2019"},{"id":"ferrari-no-25-course-clienti-488-2017","make":"Ferrari","model":"No.25 Course Clienti 488","year":"2017","name":"Ferrari No.25 Course Clienti 488 2017"},{"id":"ferrari-portofino-2018","make":"Ferrari","model":"Portofino","year":"2018","name":"Ferrari Portofino 2018"},{"id":"ferrari-roma-2020","make":"Ferrari","model":"Roma","year":"2020","name":"Ferrari Roma 2020"},{"id":"ferrari-365-gtb-4-1968","make":"Ferrari","model":"365 GTB/4","year":"1968","name":"Ferrari 365 GTB/4 1968"},{"id":"ferrari-599xx-2010","make":"Ferrari","model":"599XX","year":"2010","name":"Ferrari 599XX 2010"},{"id":"ferrari-599xx-evolution-2012","make":"Ferrari","model":"599XX Evolution","year":"2012","name":"Ferrari 599XX Evolution 2012"},{"id":"fiat-124-sport-spider-1980","make":"Fiat","model":"124 Sport Spider","year":"1980","name":"Fiat 124 Sport Spider 1980"},{"id":"ford-11-rockstar-f-150-trophy-truck-2014","make":"Ford","model":"#11 Rockstar F-150 Trophy Truck","year":"2014","name":"Ford #11 Rockstar F-150 Trophy Truck 2014"},{"id":"ford-2069-ford-bronco-r-2020","make":"Ford","model":"#2069 Ford Bronco R","year":"2020","name":"Ford #2069 Ford Bronco R 2020"},{"id":"ford-2069-ford-performance-bronco-r-2020","make":"Ford","model":"#2069 Ford Performance Bronco R","year":"2020","name":"Ford #2069 Ford Performance Bronco R 2020"},{"id":"ford-25-brocky-ultra4-bronco-rtr-2017","make":"Ford","model":"#25 \"Brocky\" Ultra4 Bronco RTR","year":"2017","name":"Ford #25 \"Brocky\" Ultra4 Bronco RTR 2017"},{"id":"ford-25-mustang-rtr-2018","make":"Ford","model":"#25 Mustang RTR","year":"2018","name":"Ford #25 Mustang RTR 2018"},{"id":"ford-4-ford-focus-rs-2001","make":"Ford","model":"#4 Ford Focus RS","year":"2001","name":"Ford #4 Ford Focus RS 2001"},{"id":"ford-5-escort-rs-1800-mkii-1977","make":"Ford","model":"#5 Escort RS 1800 MKII","year":"1977","name":"Ford #5 Escort RS 1800 MKII 1977"},{"id":"ford-88-mustang-rtr-2018","make":"Ford","model":"#88 Mustang RTR","year":"2018","name":"Ford #88 Mustang RTR 2018"},{"id":"ford-anglia-105e-1959","make":"Ford","model":"Anglia 105E","year":"1959","name":"Ford Anglia 105E 1959"},{"id":"ford-bronco-1975","make":"Ford","model":"Bronco","year":"1975","name":"Ford Bronco 1975"},{"id":"ford-bronco-2021","make":"Ford","model":"Bronco","year":"2021","name":"Ford Bronco 2021"},{"id":"ford-capri-rs3100-1973","make":"Ford","model":"Capri RS3100","year":"1973","name":"Ford Capri RS3100 1973"},{"id":"ford-crown-victoria-police-interceptor-2010","make":"Ford","model":"Crown Victoria Police Interceptor","year":"2010","name":"Ford Crown Victoria Police Interceptor 2010"},{"id":"ford-de-luxe-coupe-1940","make":"Ford","model":"De Luxe Coupe","year":"1940","name":"Ford De Luxe Coupe 1940"},{"id":"ford-de-luxe-five-window-coupe-1932","make":"Ford","model":"De Luxe Five-Window Coupe","year":"1932","name":"Ford De Luxe Five-Window Coupe 1932"},{"id":"ford-escort-rs-1600-1973","make":"Ford","model":"Escort RS 1600","year":"1973","name":"Ford Escort RS 1600 1973"},{"id":"ford-escort-rs-1800-1977","make":"Ford","model":"Escort RS 1800","year":"1977","name":"Ford Escort RS 1800 1977"},{"id":"ford-escort-rs-cosworth-1992","make":"Ford","model":"Escort RS Cosworth","year":"1992","name":"Ford Escort RS Cosworth 1992"},{"id":"ford-escort-rs-turbo","make":"Ford","model":"Escort RS Turbo","year":"","name":"Ford Escort RS Turbo"},{"id":"ford-f100-1956","make":"Ford","model":"F100","year":"1956","name":"Ford F100 1956"},{"id":"ford-f-150-raptor-2017","make":"Ford","model":"F-150 Raptor","year":"2017","name":"Ford F-150 Raptor 2017"},{"id":"ford-f-150-svt-lightning","make":"Ford","model":"F-150 SVT Lightning","year":"","name":"Ford F-150 SVT Lightning"},{"id":"ford-f-150-svt-raptor-2011","make":"Ford","model":"F-150 SVT Raptor","year":"2011","name":"Ford F-150 SVT Raptor 2011"},{"id":"ford-falcon-gt-f-351-2015","make":"Ford","model":"Falcon GT F 351","year":"2015","name":"Ford Falcon GT F 351 2015"},{"id":"ford-falcon-xa-gt-ho-1972","make":"Ford","model":"Falcon XA GT-HO","year":"1972","name":"Ford Falcon XA GT-HO 1972"},{"id":"ford-fiesta-st-2014","make":"Ford","model":"Fiesta ST","year":"2014","name":"Ford Fiesta ST 2014"},{"id":"ford-fiesta-xr2","make":"Ford","model":"Fiesta XR2","year":"","name":"Ford Fiesta XR2"},{"id":"ford-focus-rs","make":"Ford","model":"Focus RS","year":"","name":"Ford Focus RS"},{"id":"ford-focus-rs-2003","make":"Ford","model":"Focus RS","year":"2003","name":"Ford Focus RS 2003"},{"id":"ford-focus-rs-2009","make":"Ford","model":"Focus RS","year":"2009","name":"Ford Focus RS 2009"},{"id":"ford-fpv-limited-edition-pursuit-ute-2014","make":"Ford","model":"FPV Limited Edition Pursuit UTE","year":"2014","name":"Ford FPV Limited Edition Pursuit UTE 2014"},{"id":"ford-gt-2005","make":"Ford","model":"GT","year":"2005","name":"Ford GT 2005"},{"id":"ford-gt-2017","make":"Ford","model":"GT","year":"2017","name":"Ford GT 2017"},{"id":"ford-gt40-mki-1964","make":"Ford","model":"GT40 MKI","year":"1964","name":"Ford GT40 MKI 1964"},{"id":"ford-gt70-1970","make":"Ford","model":"GT70","year":"1970","name":"Ford GT70 1970"},{"id":"ford-lotus-cortina-1966","make":"Ford","model":"Lotus Cortina","year":"1966","name":"Ford Lotus Cortina 1966"},{"id":"ford-m-sport-fiesta-rs-2017","make":"Ford","model":"M-Sport Fiesta RS","year":"2017","name":"Ford M-Sport Fiesta RS 2017"},{"id":"ford-mustang-boss-302-1969","make":"Ford","model":"Mustang Boss 302","year":"1969","name":"Ford Mustang Boss 302 1969"},{"id":"ford-mustang-gt-2-2-fastback-1968","make":"Ford","model":"Mustang GT 2+2 Fastback","year":"1968","name":"Ford Mustang GT 2+2 Fastback 1968"},{"id":"ford-mustang-gt-2018","make":"Ford","model":"Mustang GT","year":"2018","name":"Ford Mustang GT 2018"},{"id":"ford-mustang-gt-coupe-1965","make":"Ford","model":"Mustang GT Coupe","year":"1965","name":"Ford Mustang GT Coupe 1965"},{"id":"ford-mustang-mach-1-1971","make":"Ford","model":"Mustang Mach 1","year":"1971","name":"Ford Mustang Mach 1 1971"},{"id":"ford-mustang-mach-e-1400-2021","make":"Ford","model":"Mustang Mach-E 1400","year":"2021","name":"Ford Mustang Mach-E 1400 2021"},{"id":"ford-mustang-rtr-spec-5-2018","make":"Ford","model":"Mustang RTR Spec 5","year":"2018","name":"Ford Mustang RTR Spec 5 2018"},{"id":"ford-mustang-shelby-gt350r-2016","make":"Ford","model":"Mustang Shelby GT350R","year":"2016","name":"Ford Mustang Shelby GT350R 2016"},{"id":"ford-mustang-shelby-gt500-2020","make":"Ford","model":"Mustang Shelby GT500","year":"2020","name":"Ford Mustang Shelby GT500 2020"},{"id":"ford-mustang-svo","make":"Ford","model":"Mustang SVO","year":"","name":"Ford Mustang SVO"},{"id":"ford-no-14-rahal-letterman-lanigan-racing-fiesta-2017","make":"Ford","model":"No. 14 Rahal Letterman Lanigan Racing Fiesta","year":"2017","name":"Ford No. 14 Rahal Letterman Lanigan Racing Fiesta 2017"},{"id":"ford-no-2-gt40-mk-ii-1965","make":"Ford","model":"No.2 GT40 Mk II","year":"1965","name":"Ford No.2 GT40 Mk II 1965"},{"id":"ford-racing-escort-mk1","make":"Ford","model":"Racing Escort MK1","year":"","name":"Ford Racing Escort MK1"},{"id":"ford-racing-puma-1999","make":"Ford","model":"Racing Puma","year":"1999","name":"Ford Racing Puma 1999"},{"id":"ford-racing-puma-forza-edition","make":"Ford","model":"Racing Puma Forza Edition","year":"","name":"Ford Racing Puma Forza Edition"},{"id":"ford-ranger-raptor-2019","make":"Ford","model":"Ranger Raptor","year":"2019","name":"Ford Ranger Raptor 2019"},{"id":"ford-ranger-t6-rally-raid-2014","make":"Ford","model":"Ranger T6 Rally Raid","year":"2014","name":"Ford Ranger T6 Rally Raid 2014"},{"id":"ford-rs200-evolution-1985","make":"Ford","model":"RS200 Evolution","year":"1985","name":"Ford RS200 Evolution 1985"},{"id":"ford-shelby-gt500-2013","make":"Ford","model":"Shelby GT500","year":"2013","name":"Ford Shelby GT500 2013"},{"id":"ford-sierra-cosworth-rs500-1987","make":"Ford","model":"Sierra Cosworth RS500","year":"1987","name":"Ford Sierra Cosworth RS500 1987"},{"id":"ford-suoervan-3-donut-esition-1994","make":"Ford","model":"Suoervan 3 Donut Esition","year":"1994","name":"Ford Suoervan 3 Donut Esition 1994"},{"id":"ford-super-duty-f-145-drw-platinum-2020","make":"Ford","model":"Super Duty F-145 DRW Platinum","year":"2020","name":"Ford Super Duty F-145 DRW Platinum 2020"},{"id":"ford-supervan-3-1994","make":"Ford","model":"Supervan 3","year":"1994","name":"Ford Supervan 3 1994"},{"id":"ford-supervan-4-2022","make":"Ford","model":"Supervan 4","year":"2022","name":"Ford Supervan 4 2022"},{"id":"ford-svt-cobra-r-1993","make":"Ford","model":"SVT Cobra R","year":"1993","name":"Ford SVT Cobra R 1993"},{"id":"ford-svt-cobra-r-2000","make":"Ford","model":"SVT Cobra R","year":"2000","name":"Ford SVT Cobra R 2000"},{"id":"ford-transit-1965","make":"Ford","model":"Transit","year":"1965","name":"Ford Transit 1965"},{"id":"ford-transit-supersportvan-2011","make":"Ford","model":"Transit Supersportvan","year":"2011","name":"Ford Transit Supersportvan 2011"},{"id":"formula-drift-117-599-gtb-fiorano-2007","make":"Formula Drift","model":"#117 599 GTB Fiorano","year":"2007","name":"Formula Drift #117 599 GTB Fiorano 2007"},{"id":"formula-drift-13-ford-mustang-2015","make":"Formula Drift","model":"#13 Ford Mustang","year":"2015","name":"Formula Drift #13 Ford Mustang 2015"},{"id":"formula-drift-151-toyota-gr-supra","make":"Formula Drift","model":"#151 Toyota GR Supra","year":"","name":"Formula Drift #151 Toyota GR Supra"},{"id":"formula-drift-34-toyota-supra-mkiv","make":"Formula Drift","model":"#34 Toyota Supra MKIV","year":"","name":"Formula Drift #34 Toyota Supra MKIV"},{"id":"formula-drift-357-chevrolet-corvette","make":"Formula Drift","model":"#357 Chevrolet Corvette","year":"","name":"Formula Drift #357 Chevrolet Corvette"},{"id":"formula-drift-411-toyota-corolla-hatchback","make":"Formula Drift","model":"#411 Toyota Corolla Hatchback","year":"","name":"Formula Drift #411 Toyota Corolla Hatchback"},{"id":"formula-drift-43-dodge-viper-srt-10-2006","make":"Formula Drift","model":"#43 Dodge Viper SRT 10","year":"2006","name":"Formula Drift #43 Dodge Viper SRT 10 2006"},{"id":"formula-drift-51-donut-media-nissan-240sx-1996","make":"Formula Drift","model":"#51 Donut Media Nissan 240SX","year":"1996","name":"Formula Drift #51 Donut Media Nissan 240SX 1996"},{"id":"formula-drift-530-hsv-maloo-gen-f-2016","make":"Formula Drift","model":"#530 HSV Maloo Gen-F","year":"2016","name":"Formula Drift #530 HSV Maloo Gen-F 2016"},{"id":"formula-drift-64-nissan-370z-2018","make":"Formula Drift","model":"#64 Nissan 370Z","year":"2018","name":"Formula Drift #64 Nissan 370Z 2018"},{"id":"formula-drift-777-chevrolet-corvette-2013","make":"Formula Drift","model":"#777 Chevrolet Corvette","year":"2013","name":"Formula Drift #777 Chevrolet Corvette 2013"},{"id":"formula-drift-777-nissan-240sx-1997","make":"Formula Drift","model":"#777 Nissan 240SX","year":"1997","name":"Formula Drift #777 Nissan 240SX 1997"},{"id":"formula-drift-98-bmw-325i-1989","make":"Formula Drift","model":"#98 BMW 325I","year":"1989","name":"Formula Drift #98 BMW 325I 1989"},{"id":"formula-drift-99-mazda-rx-8","make":"Formula Drift","model":"#99 Mazda RX-8","year":"","name":"Formula Drift #99 Mazda RX-8"},{"id":"formula-drift-no-91-bmw-m2","make":"Formula Drift","model":"No.91 BMW M2","year":"","name":"Formula Drift No.91 BMW M2"},{"id":"forsberg-racing-nissan-safariz-370z-safari-rally-tribute-2014","make":"Forsberg","model":"Racing Nissan \"Safariz\" 370Z Safari Rally Tribute","year":"2014","name":"Forsberg Racing Nissan \"Safariz\" 370Z Safari Rally Tribute 2014"},{"id":"forsberg-racing-nissan-altimaniac-2021","make":"Forsberg","model":"Racing Nissan 'Altimaniac'","year":"2021","name":"Forsberg Racing Nissan 'Altimaniac' 2021"},{"id":"forsberg-racing-nissan-gold-leader-datsun-280z-1975","make":"Forsberg","model":"Racing Nissan Gold Leader Datsun 280Z","year":"1975","name":"Forsberg Racing Nissan Gold Leader Datsun 280Z 1975"},{"id":"forsberg-racing-toyota-gumout-2jz-camry-stovk-car-2010","make":"Forsberg","model":"Racing Toyota Gumout 2JZ Camry Stovk Car","year":"2010","name":"Forsberg Racing Toyota Gumout 2JZ Camry Stovk Car 2010"},{"id":"funco-motorsports-f9-2018","make":"Funco Motorsports","model":"F9","year":"2018","name":"Funco Motorsports F9 2018"},{"id":"ginetta-g10-rm-2019","make":"Ginetta","model":"G10 RM","year":"2019","name":"Ginetta G10 RM 2019"},{"id":"gmc-barbie-movie-hummer-ev-pick-up-2022","make":"GMC","model":"Barbie Movie Hummer EV Pick-Up","year":"2022","name":"GMC Barbie Movie Hummer EV Pick-Up 2022"},{"id":"gmc-jimmy-1970","make":"GMC","model":"Jimmy","year":"1970","name":"GMC Jimmy 1970"},{"id":"gmc-vandura-g-1500-1983","make":"GMC","model":"Vandura G-1500","year":"1983","name":"GMC Vandura G-1500 1983"},{"id":"gremlin-x-1973","make":"Gremlin","model":"X","year":"1973","name":"Gremlin X 1973"},{"id":"hennessy-camaro-exorcist-2019","make":"Hennessy","model":"Camaro Exorcist","year":"2019","name":"Hennessy Camaro Exorcist 2019"},{"id":"hennessy-velociraptor-6x6-2019","make":"Hennessy","model":"Velociraptor 6x6","year":"2019","name":"Hennessy Velociraptor 6x6 2019"},{"id":"hennessy-venom-gt-2012","make":"Hennessy","model":"Venom GT","year":"2012","name":"Hennessy Venom GT 2012"},{"id":"holden-hq-monaro-gts-350-1973","make":"Holden","model":"HQ Monaro GTS 350","year":"1973","name":"Holden HQ Monaro GTS 350 1973"},{"id":"holden-sandman-hq-panel-van-1974","make":"Holden","model":"Sandman HQ Panel Van","year":"1974","name":"Holden Sandman HQ Panel Van 1974"},{"id":"holden-torana-a9x-1977","make":"Holden","model":"Torana A9X","year":"1977","name":"Holden Torana A9X 1977"},{"id":"honda-civic-crx-mugen-1984","make":"Honda","model":"Civic CRX Mugen","year":"1984","name":"Honda Civic CRX Mugen 1984"},{"id":"honda-civic-rs-1974","make":"Honda","model":"Civic RS","year":"1974","name":"Honda Civic RS 1974"},{"id":"honda-civic-tyoe-r-1997","make":"Honda","model":"Civic Tyoe R","year":"1997","name":"Honda Civic Tyoe R 1997"},{"id":"honda-civic-type-r-2004","make":"Honda","model":"Civic Type R","year":"2004","name":"Honda Civic Type R 2004"},{"id":"honda-civic-type-r-2007","make":"Honda","model":"Civic Type R","year":"2007","name":"Honda Civic Type R 2007"},{"id":"honda-civic-type-r-2016","make":"Honda","model":"Civic Type R","year":"2016","name":"Honda Civic Type R 2016"},{"id":"honda-civic-type-r-2018","make":"Honda","model":"Civic Type R","year":"2018","name":"Honda Civic Type R 2018"},{"id":"honda-cr-x-sir-1991","make":"Honda","model":"CR-X SIR","year":"1991","name":"Honda CR-X SIR 1991"},{"id":"honda-msx-r-2005","make":"Honda","model":"MSX-R","year":"2005","name":"Honda MSX-R 2005"},{"id":"honda-nsx-r-1992","make":"Honda","model":"NSX-R","year":"1992","name":"Honda NSX-R 1992"},{"id":"honda-prelude-si-1994","make":"Honda","model":"Prelude SI","year":"1994","name":"Honda Prelude SI 1994"},{"id":"honda-s2000-2003","make":"Honda","model":"S2000","year":"2003","name":"Honda S2000 2003"},{"id":"honda-s2000-cr-2009","make":"Honda","model":"S2000 CR","year":"2009","name":"Honda S2000 CR 2009"},{"id":"hoonigan-chevrolet-bel-air","make":"Hoonigan","model":"Chevrolet Bel Air","year":"","name":"Hoonigan Chevrolet Bel Air"},{"id":"hoonigan-chevrolet-napalm-nova-1972","make":"Hoonigan","model":"Chevrolet Napalm Nova","year":"1972","name":"Hoonigan Chevrolet Napalm Nova 1972"},{"id":"hoonigan-ford-hoonicorn-mustang","make":"Hoonigan","model":"Ford \"Hoonicorn\" Mustang","year":"","name":"Hoonigan Ford \"Hoonicorn\" Mustang"},{"id":"hoonigan-ford-escort-rs-cosworth","make":"Hoonigan","model":"Ford Escort RS Cosworth","year":"","name":"Hoonigan Ford Escort RS Cosworth"},{"id":"hoonigan-ford-escort-rs1800-1978","make":"Hoonigan","model":"Ford Escort RS1800","year":"1978","name":"Hoonigan Ford Escort RS1800 1978"},{"id":"hoonigan-ford-rs200-evolution-1986","make":"Hoonigan","model":"Ford RS200 Evolution","year":"1986","name":"Hoonigan Ford RS200 Evolution 1986"},{"id":"hoonigan-gymkhana-10-ford-escort-cosworth-group-a-1991","make":"Hoonigan","model":"Gymkhana 10 Ford Escort Cosworth Group A","year":"1991","name":"Hoonigan Gymkhana 10 Ford Escort Cosworth Group A 1991"},{"id":"hoonigan-gymkhana-10-ford-f-150-hoonitruck-1977","make":"Hoonigan","model":"Gymkhana 10 Ford F-150 Hoonitruck","year":"1977","name":"Hoonigan Gymkhana 10 Ford F-150 Hoonitruck 1977"},{"id":"hoonigan-gymkhana-10-ford-focus-rs-rx-2016","make":"Hoonigan","model":"Gymkhana 10 Ford Focus RS RX","year":"2016","name":"Hoonigan Gymkhana 10 Ford Focus RS RX 2016"},{"id":"hoonigan-volkswagen-baja-beetle-class-5-1600-scumbug-1973","make":"Hoonigan","model":"Volkswagen Baja Beetle Class 5/1600 Scumbug","year":"1973","name":"Hoonigan Volkswagen Baja Beetle Class 5/1600 Scumbug 1973"},{"id":"hot-wheels-baja-bone-shaker-2013","make":"Hot Wheels","model":"Baja Bone Shaker","year":"2013","name":"Hot Wheels Baja Bone Shaker 2013"},{"id":"hot-wheels-bone-shaker-2011","make":"Hot Wheels","model":"Bone Shaker","year":"2011","name":"Hot Wheels Bone Shaker 2011"},{"id":"hot-wheels-deora-ii-2000","make":"Hot Wheels","model":"Deora II","year":"2000","name":"Hot Wheels Deora II 2000"},{"id":"hot-wheels-ford-f-5-dually-custom-hot-rod-1949","make":"Hot Wheels","model":"Ford F-5 Dually Custom Hot Rod","year":"1949","name":"Hot Wheels Ford F-5 Dually Custom Hot Rod 1949"},{"id":"hot-wheels-ford-mustang-2005","make":"Hot Wheels","model":"Ford Mustang","year":"2005","name":"Hot Wheels Ford Mustang 2005"},{"id":"hot-wheels-nash-metropolitan-custom-1957","make":"Hot Wheels","model":"Nash Metropolitan Custom","year":"1957","name":"Hot Wheels Nash Metropolitan Custom 1957"},{"id":"hot-wheels-rip-rod-2012","make":"Hot Wheels","model":"Rip Rod","year":"2012","name":"Hot Wheels Rip Rod 2012"},{"id":"hsv-gen-f-gts-2014","make":"HSV","model":"Gen-F GTS","year":"2014","name":"HSV Gen-F GTS 2014"},{"id":"hsv-limited-edition-gen-f-gts-maloo-2014","make":"HSV","model":"Limited Edition Gen-F GTS Maloo","year":"2014","name":"HSV Limited Edition Gen-F GTS Maloo 2014"},{"id":"hummer-h1-alpha-2006","make":"Hummer","model":"H1 Alpha","year":"2006","name":"Hummer H1 Alpha 2006"},{"id":"hyundai-veloster-n-2019","make":"Hyundai","model":"Veloster N","year":"2019","name":"Hyundai Veloster N 2019"},{"id":"infiniti-q60-concept-2015","make":"Infiniti","model":"Q60 Concept","year":"2015","name":"Infiniti Q60 Concept 2015"},{"id":"international-scout-800a-1970","make":"International Scout","model":"800A","year":"1970","name":"International Scout 800A 1970"},{"id":"italdesign-davinci-concept-2019","make":"Italdesign","model":"DaVinci Concept","year":"2019","name":"Italdesign DaVinci Concept 2019"},{"id":"italdesign-zerouno-2018","make":"Italdesign","model":"Zerouno","year":"2018","name":"Italdesign Zerouno 2018"},{"id":"jaguar-c-x75-2010","make":"Jaguar","model":"C-X75","year":"2010","name":"Jaguar C-X75 2010"},{"id":"jaguar-d-type-1956","make":"Jaguar","model":"D-Type","year":"1956","name":"Jaguar D-Type 1956"},{"id":"jaguar-e-type-1961","make":"Jaguar","model":"E-Type","year":"1961","name":"Jaguar E-Type 1961"},{"id":"jaguar-f-pace-s-2017","make":"Jaguar","model":"F-Pace S","year":"2017","name":"Jaguar F-Pace S 2017"},{"id":"jaguar-f-type-project-7-2016","make":"Jaguar","model":"F-Type Project 7","year":"2016","name":"Jaguar F-Type Project 7 2016"},{"id":"jaguar-f-type-r-coupe-2015","make":"Jaguar","model":"F-Type R Coupe","year":"2015","name":"Jaguar F-Type R Coupe 2015"},{"id":"jaguar-i-pace-2018","make":"Jaguar","model":"I-Pace","year":"2018","name":"Jaguar I-Pace 2018"},{"id":"jaguar-lightweight-e-type-1964","make":"Jaguar","model":"Lightweight E-Type","year":"1964","name":"Jaguar Lightweight E-Type 1964"},{"id":"jaguar-mk-ii-3-8-1959","make":"Jaguar","model":"MK II 3.8","year":"1959","name":"Jaguar MK II 3.8 1959"},{"id":"jaguar-sport-xjr-15","make":"Jaguar","model":"Sport XJR-15","year":"","name":"Jaguar Sport XJR-15"},{"id":"jaguar-xe-5v-project-8-2019","make":"Jaguar","model":"XE 5V Project 8","year":"2019","name":"Jaguar XE 5V Project 8 2019"},{"id":"jaguar-xe-s-2015","make":"Jaguar","model":"XE-S","year":"2015","name":"Jaguar XE-S 2015"},{"id":"jaguar-xfr-s-2015","make":"Jaguar","model":"XFR-S","year":"2015","name":"Jaguar XFR-S 2015"},{"id":"jaguar-xj13-1966","make":"Jaguar","model":"XJ13","year":"1966","name":"Jaguar XJ13 1966"},{"id":"jaguar-xj220-1993","make":"Jaguar","model":"XJ220","year":"1993","name":"Jaguar XJ220 1993"},{"id":"jaguar-xj220s-twr-1993","make":"Jaguar","model":"XJ220S TWR","year":"1993","name":"Jaguar XJ220S TWR 1993"},{"id":"jaguar-xkr-s-2012","make":"Jaguar","model":"XKR-S","year":"2012","name":"Jaguar XKR-S 2012"},{"id":"jeep-cj5-renegade-1976","make":"Jeep","model":"CJ5 Renegade","year":"1976","name":"Jeep CJ5 Renegade 1976"},{"id":"jeep-gladiator-rubicon-2020","make":"Jeep","model":"Gladiator Rubicon","year":"2020","name":"Jeep Gladiator Rubicon 2020"},{"id":"jeep-grand-cherokee-srt-2014","make":"Jeep","model":"Grand Cherokee SRT","year":"2014","name":"Jeep Grand Cherokee SRT 2014"},{"id":"jeep-grand-cherokee-trackhawk-2018","make":"Jeep","model":"Grand Cherokee Trackhawk","year":"2018","name":"Jeep Grand Cherokee Trackhawk 2018"},{"id":"jeep-trailcat-2016","make":"Jeep","model":"Trailcat","year":"2016","name":"Jeep Trailcat 2016"},{"id":"jeep-wrangler-rubicon-2012","make":"Jeep","model":"Wrangler Rubicon","year":"2012","name":"Jeep Wrangler Rubicon 2012"},{"id":"jimco-179-hammerhead-class-1-2020","make":"Jimco","model":"#179 Hammerhead Class 1","year":"2020","name":"Jimco #179 Hammerhead Class 1 2020"},{"id":"jimco-240-fastball-racing-spec-trophy-truck-2019","make":"Jimco","model":"#240 Fastball Racing Spec Trophy Truck","year":"2019","name":"Jimco #240 Fastball Racing Spec Trophy Truck 2019"},{"id":"koenigsegg-agera-rs-2017","make":"Koenigsegg","model":"Agera RS","year":"2017","name":"Koenigsegg Agera RS 2017"},{"id":"koenigsegg-ccbs-2002","make":"Koenigsegg","model":"CCBS","year":"2002","name":"Koenigsegg CCBS 2002"},{"id":"koenigsegg-jesko-2020","make":"Koenigsegg","model":"Jesko","year":"2020","name":"Koenigsegg Jesko 2020"},{"id":"koenigsegg-one-1-2015","make":"Koenigsegg","model":"One:1","year":"2015","name":"Koenigsegg One:1 2015"},{"id":"koenigsegg-regera-2016","make":"Koenigsegg","model":"Regera","year":"2016","name":"Koenigsegg Regera 2016"},{"id":"ktm-x-bow-gt2-2020","make":"KTM","model":"X-Bow GT2","year":"2020","name":"KTM X-Bow GT2 2020"},{"id":"ktm-x-bow-r-2013","make":"KTM","model":"X-Bow R","year":"2013","name":"KTM X-Bow R 2013"},{"id":"lamborghini-63-squadra-corse-huracan-super-trofeo-evo-2018","make":"Lamborghini","model":"#63 Squadra Corse Huracan Super Trofeo EVO","year":"2018","name":"Lamborghini #63 Squadra Corse Huracan Super Trofeo EVO 2018"},{"id":"lamborghini-aventador-lp700-4-2012","make":"Lamborghini","model":"Aventador LP700-4","year":"2012","name":"Lamborghini Aventador LP700-4 2012"},{"id":"lamborghini-aventador-superveloce-2016","make":"Lamborghini","model":"Aventador Superveloce","year":"2016","name":"Lamborghini Aventador Superveloce 2016"},{"id":"lamborghini-centenario-lp-770-4-2016","make":"Lamborghini","model":"Centenario LP 770-4","year":"2016","name":"Lamborghini Centenario LP 770-4 2016"},{"id":"lamborghini-countach-lp5000-qv-1988","make":"Lamborghini","model":"Countach LP5000 QV","year":"1988","name":"Lamborghini Countach LP5000 QV 1988"},{"id":"lamborghini-diablo-sv-1997","make":"Lamborghini","model":"Diablo SV","year":"1997","name":"Lamborghini Diablo SV 1997"},{"id":"lamborghini-espada-400-gt","make":"Lamborghini","model":"Espada 400 GT","year":"","name":"Lamborghini Espada 400 GT"},{"id":"lamborghini-essenza-scv12-2020","make":"Lamborghini","model":"Essenza SCV12","year":"2020","name":"Lamborghini Essenza SCV12 2020"},{"id":"lamborghini-gallardo-lp-570-4-superleggera-2011","make":"Lamborghini","model":"Gallardo LP 570-4 Superleggera","year":"2011","name":"Lamborghini Gallardo LP 570-4 Superleggera 2011"},{"id":"lamborghini-huracan-evo-2020","make":"Lamborghini","model":"Huracan EVO","year":"2020","name":"Lamborghini Huracan EVO 2020"},{"id":"lamborghini-huracan-lp-610-4-2014","make":"Lamborghini","model":"Huracan LP 610-4","year":"2014","name":"Lamborghini Huracan LP 610-4 2014"},{"id":"lamborghini-huracan-performante-2018","make":"Lamborghini","model":"Huracan Performante","year":"2018","name":"Lamborghini Huracan Performante 2018"},{"id":"lamborghini-huracan-sto-2020","make":"Lamborghini","model":"Huracan STO","year":"2020","name":"Lamborghini Huracan STO 2020"},{"id":"lamborghini-huracan-tecnica-2022","make":"Lamborghini","model":"Huracan Tecnica","year":"2022","name":"Lamborghini Huracan Tecnica 2022"},{"id":"lamborghini-lm-002-1986","make":"Lamborghini","model":"LM 002","year":"1986","name":"Lamborghini LM 002 1986"},{"id":"lamborghini-miura-p400-1967","make":"Lamborghini","model":"Miura P400","year":"1967","name":"Lamborghini Miura P400 1967"},{"id":"lamborghini-murcielago-lp-670-4-sv-2010","make":"Lamborghini","model":"Murcielago LP 670-4 SV","year":"2010","name":"Lamborghini Murcielago LP 670-4 SV 2010"},{"id":"lamborghini-reventon-2008","make":"Lamborghini","model":"Reventon","year":"2008","name":"Lamborghini Reventon 2008"},{"id":"lamborghini-revuelto-2024","make":"Lamborghini","model":"Revuelto","year":"2024","name":"Lamborghini Revuelto 2024"},{"id":"lamborghini-sc20-2020","make":"Lamborghini","model":"SC20","year":"2020","name":"Lamborghini SC20 2020"},{"id":"lamborghini-sesto-elemento-2011","make":"Lamborghini","model":"Sesto Elemento","year":"2011","name":"Lamborghini Sesto Elemento 2011"},{"id":"lamborghini-sesto-elemento-forza-edition-2011","make":"Lamborghini","model":"Sesto Elemento Forza Edition","year":"2011","name":"Lamborghini Sesto Elemento Forza Edition 2011"},{"id":"lamborghini-sian-roadster-2020","make":"Lamborghini","model":"Sian Roadster","year":"2020","name":"Lamborghini Sian Roadster 2020"},{"id":"lamborghini-urus-2019","make":"Lamborghini","model":"Urus","year":"2019","name":"Lamborghini Urus 2019"},{"id":"lamborghini-countach-lp5000-qv-1988","make":"Lamborghini","model":"Countach LP5000 QV","year":"1988","name":"Lamborghini Countach LP5000 QV 1988"},{"id":"lancia-delta-hf-intergrale-evo-1992","make":"Lancia","model":"Delta HF Intergrale Evo","year":"1992","name":"Lancia Delta HF Intergrale Evo 1992"},{"id":"lancia-stratos-hf-stradale-1974","make":"Lancia","model":"Stratos HF Stradale","year":"1974","name":"Lancia Stratos HF Stradale 1974"},{"id":"land-rover-defender-110-x-2020","make":"Land Rover","model":"Defender 110 X","year":"2020","name":"Land Rover Defender 110 X 2020"},{"id":"land-rover-defender-90-1997","make":"Land Rover","model":"Defender 90","year":"1997","name":"Land Rover Defender 90 1997"},{"id":"land-rover-range-rover-1973","make":"Land Rover","model":"Range Rover","year":"1973","name":"Land Rover Range Rover 1973"},{"id":"land-rover-range-rover-sport-svr-2015","make":"Land Rover","model":"Range Rover Sport SVR","year":"2015","name":"Land Rover Range Rover Sport SVR 2015"},{"id":"land-rover-range-rover-velar-fe-2018","make":"Land Rover","model":"Range Rover Velar FE","year":"2018","name":"Land Rover Range Rover Velar FE 2018"},{"id":"land-rover-series-iii-1972","make":"Land Rover","model":"Series III","year":"1972","name":"Land Rover Series III 1972"},{"id":"lexus-14-vasser-sullivan-rc-f-gt3-2020","make":"Lexus","model":"#14 Vasser Sullivan RC F GT3","year":"2020","name":"Lexus #14 Vasser Sullivan RC F GT3 2020"},{"id":"lexus-lfa-2010","make":"Lexus","model":"LFA","year":"2010","name":"Lexus LFA 2010"},{"id":"lexus-rc-f-2015","make":"Lexus","model":"RC F","year":"2015","name":"Lexus RC F 2015"},{"id":"lexus-rc-f-track-edition","make":"Lexus","model":"RC F Track Edition","year":"","name":"Lexus RC F Track Edition"},{"id":"lexus-sc300-1997","make":"Lexus","model":"SC300","year":"1997","name":"Lexus SC300 1997"},{"id":"local-motors-rally-fighter-2014","make":"Local Motors","model":"Rally Fighter","year":"2014","name":"Local Motors Rally Fighter 2014"},{"id":"lola-6-penske-sunoco-t70-mkiiib-1969","make":"Lola","model":"#6 Penske Sunoco T70 MkIIIB","year":"1969","name":"Lola #6 Penske Sunoco T70 MkIIIB 1969"},{"id":"lotus-3-eleven-2016","make":"Lotus","model":"3-Eleven","year":"2016","name":"Lotus 3-Eleven 2016"},{"id":"lotus-elan-sprint-1971","make":"Lotus","model":"Elan Sprint","year":"1971","name":"Lotus Elan Sprint 1971"},{"id":"lotus-elise-gt1-1997","make":"Lotus","model":"Elise GT1","year":"1997","name":"Lotus Elise GT1 1997"},{"id":"lotus-elise-series-1-sport-190-1999","make":"Lotus","model":"Elise Series 1 Sport 190","year":"1999","name":"Lotus Elise Series 1 Sport 190 1999"},{"id":"lotus-emirates-2023","make":"Lotus","model":"Emirates","year":"2023","name":"Lotus Emirates 2023"},{"id":"lotus-evija-2020","make":"Lotus","model":"Evija","year":"2020","name":"Lotus Evija 2020"},{"id":"lotus-exige-s-2012","make":"Lotus","model":"Exige S","year":"2012","name":"Lotus Exige S 2012"},{"id":"lynk-co-03-2021","make":"Lynk & Co","model":"03+","year":"2021","name":"Lynk & Co 03+ 2021"},{"id":"lynk-co-o5-2022","make":"Lynk & Co","model":"O5+","year":"2022","name":"Lynk & Co O5+ 2022"},{"id":"maserati-gran-turismo-s-2010","make":"Maserati","model":"Gran Turismo S","year":"2010","name":"Maserati Gran Turismo S 2010"},{"id":"maserati-gran-turismo-s-forza-edition-2010","make":"Maserati","model":"Gran Turismo S Forza Edition","year":"2010","name":"Maserati Gran Turismo S Forza Edition 2010"},{"id":"maserati-levante-s","make":"Maserati","model":"Levante S","year":"","name":"Maserati Levante S"},{"id":"mazda-323-gt-r-1992","make":"Mazda","model":"323 GT-R","year":"1992","name":"Mazda 323 GT-R 1992"},{"id":"mazda-mazdaspeed-mx-5-2006","make":"Mazda","model":"Mazdaspeed MX-5","year":"2006","name":"Mazda Mazdaspeed MX-5 2006"},{"id":"mazda-mx-5-2013","make":"Mazda","model":"MX-5","year":"2013","name":"Mazda MX-5 2013"},{"id":"mazda-mx-5-2016","make":"Mazda","model":"MX-5","year":"2016","name":"Mazda MX-5 2016"},{"id":"mazda-mx-5-miata-1994","make":"Mazda","model":"MX-5 Miata","year":"1994","name":"Mazda MX-5 Miata 1994"},{"id":"mazda-rx-7-1997","make":"Mazda","model":"RX-7","year":"1997","name":"Mazda RX-7 1997"},{"id":"mazda-rx-7-spirit-r-type-a-2002","make":"Mazda","model":"RX-7 Spirit R Type-A","year":"2002","name":"Mazda RX-7 Spirit R Type-A 2002"},{"id":"mazda-rx-8-r3-2011","make":"Mazda","model":"RX-8 R3","year":"2011","name":"Mazda RX-8 R3 2011"},{"id":"mazda-savanna-rx-7-1990","make":"Mazda","model":"Savanna RX-7","year":"1990","name":"Mazda Savanna RX-7 1990"},{"id":"mclaren-570s-coupe-2015","make":"McLaren","model":"570S Coupe","year":"2015","name":"McLaren 570S Coupe 2015"},{"id":"mclaren-600lt-coupe-2018","make":"McLaren","model":"600LT Coupe","year":"2018","name":"McLaren 600LT Coupe 2018"},{"id":"mclaren-620r-2021","make":"McLaren","model":"620R","year":"2021","name":"McLaren 620R 2021"},{"id":"mclaren-650s-coupe-2015","make":"McLaren","model":"650S Coupe","year":"2015","name":"McLaren 650S Coupe 2015"},{"id":"mclaren-720s-coupe-2018","make":"McLaren","model":"720S Coupe","year":"2018","name":"McLaren 720S Coupe 2018"},{"id":"mclaren-720s-spider-2019","make":"McLaren","model":"720S Spider","year":"2019","name":"McLaren 720S Spider 2019"},{"id":"mclaren-f1-gt-1997","make":"McLaren","model":"F1 GT","year":"1997","name":"McLaren F1 GT 1997"},{"id":"mclaren-gt-2020","make":"McLaren","model":"GT","year":"2020","name":"McLaren GT 2020"},{"id":"mclaren-p1-2013","make":"McLaren","model":"P1","year":"2013","name":"McLaren P1 2013"},{"id":"mclaren-sabre-2021","make":"McLaren","model":"Sabre","year":"2021","name":"McLaren Sabre 2021"},{"id":"mclaren-senna-2018","make":"McLaren","model":"Senna","year":"2018","name":"McLaren Senna 2018"},{"id":"mclaren-speedtail-2019","make":"McLaren","model":"Speedtail","year":"2019","name":"McLaren Speedtail 2019"},{"id":"mercedes-amg-c-63-s-coupe-2016","make":"Mercedes-AMG","model":"C 63 S Coupe","year":"2016","name":"Mercedes-AMG C 63 S Coupe 2016"},{"id":"mercedes-amg-e-63-s-2018","make":"Mercedes-AMG","model":"E 63 S","year":"2018","name":"Mercedes-AMG E 63 S 2018"},{"id":"mercedes-amg-gt-4-door-coupe-2018","make":"Mercedes-AMG","model":"GT 4-Door Coupe","year":"2018","name":"Mercedes-AMG GT 4-Door Coupe 2018"},{"id":"mercedes-amg-gt-r-2017","make":"Mercedes-AMG","model":"GT R","year":"2017","name":"Mercedes-AMG GT R 2017"},{"id":"mercedes-amg-gt3-2018","make":"Mercedes-AMG","model":"GT3","year":"2018","name":"Mercedes-AMG GT3 2018"},{"id":"mercedes-amg-mercedes-amg-one-2021","make":"Mercedes-AMG","model":"Mercedes-AMG One","year":"2021","name":"Mercedes-AMG Mercedes-AMG One 2021"},{"id":"mercedes-benz-24-tankpool-24-racing-truck-2015","make":"Mercedes-Benz","model":"#24 Tankpool 24 Racing Truck","year":"2015","name":"Mercedes-Benz #24 Tankpool 24 Racing Truck 2015"},{"id":"mercedes-benz-24-tankpool-24-racing-truck-forza-edition-2015","make":"Mercedes-Benz","model":"#24 Tankpool 24 Racing Truck Forza Edition","year":"2015","name":"Mercedes-Benz #24 Tankpool 24 Racing Truck Forza Edition 2015"},{"id":"mercedes-benz-190e-2-5-16-evolution-ii-1990","make":"Mercedes-Benz","model":"190E 2.5-16 Evolution II","year":"1990","name":"Mercedes-Benz 190E 2.5-16 Evolution II 1990"},{"id":"mercedes-benz-300-slr-1955","make":"Mercedes-Benz","model":"300 SLR","year":"1955","name":"Mercedes-Benz 300 SLR 1955"},{"id":"mercedes-benz-300-slr-coupe-1954","make":"Mercedes-Benz","model":"300 SLR Coupe","year":"1954","name":"Mercedes-Benz 300 SLR Coupe 1954"},{"id":"mercedes-benz-a-45-amg-2013","make":"Mercedes-Benz","model":"A 45 AMG","year":"2013","name":"Mercedes-Benz A 45 AMG 2013"},{"id":"mercedes-benz-amg-clk-gtr-1998","make":"Mercedes-Benz","model":"AMG CLK GTR","year":"1998","name":"Mercedes-Benz AMG CLK GTR 1998"},{"id":"mercedes-benz-amg-clk-gtr-forza-edition","make":"Mercedes-Benz","model":"AMG CLK GTR Forza Edition","year":"","name":"Mercedes-Benz AMG CLK GTR Forza Edition"},{"id":"mercedes-benz-amg-hammer-coupe-1987","make":"Mercedes-Benz","model":"AMG Hammer Coupe","year":"1987","name":"Mercedes-Benz AMG Hammer Coupe 1987"},{"id":"mercedes-benz-amg-hammer-wagon-1986","make":"Mercedes-Benz","model":"AMG Hammer Wagon","year":"1986","name":"Mercedes-Benz AMG Hammer Wagon 1986"},{"id":"mercedes-benz-c-63-amg-coupe-black-series-2012","make":"Mercedes-Benz","model":"C 63 AMG Coupe Black Series","year":"2012","name":"Mercedes-Benz C 63 AMG Coupe Black Series 2012"},{"id":"mercedes-benz-e-63-amg-2013","make":"Mercedes-Benz","model":"E 63 AMG","year":"2013","name":"Mercedes-Benz E 63 AMG 2013"},{"id":"mercedes-benz-g-63-amg-6x6-2014","make":"Mercedes-Benz","model":"G 63 AMG 6X6","year":"2014","name":"Mercedes-Benz G 63 AMG 6X6 2014"},{"id":"mercedes-benz-g-65-amg-2013","make":"Mercedes-Benz","model":"G 65 AMG","year":"2013","name":"Mercedes-Benz G 65 AMG 2013"},{"id":"mercedes-benz-slk-55-amg-2012","make":"Mercedes-Benz","model":"SLK 55 AMG","year":"2012","name":"Mercedes-Benz SLK 55 AMG 2012"},{"id":"mercedes-benz-sls-amg-2011","make":"Mercedes-Benz","model":"SLS AMG","year":"2011","name":"Mercedes-Benz SLS AMG 2011"},{"id":"mercedes-benz-unimog-u5023-2014","make":"Mercedes-Benz","model":"Unimog U5023","year":"2014","name":"Mercedes-Benz Unimog U5023 2014"},{"id":"mercedes-benz-w154-1939","make":"Mercedes-Benz","model":"W154","year":"1939","name":"Mercedes-Benz W154 1939"},{"id":"mercedes-benz-x-class-2018","make":"Mercedes-Benz","model":"X-Class","year":"2018","name":"Mercedes-Benz X-Class 2018"},{"id":"mercury-cyclone-spoiler-1970","make":"Mercury","model":"Cyclone Spoiler","year":"1970","name":"Mercury Cyclone Spoiler 1970"},{"id":"meyers-manx-1971","make":"Meyers","model":"Manx","year":"1971","name":"Meyers Manx 1971"},{"id":"meyers-manx-fe-1971","make":"Meyers Manx","model":"FE","year":"1971","name":"Meyers Manx FE 1971"},{"id":"mg-cyberster-2023","make":"MG","model":"Cyberster","year":"2023","name":"MG Cyberster 2023"},{"id":"mg-metro-gr4-1986","make":"MG","model":"Metro GR4","year":"1986","name":"MG Metro GR4 1986"},{"id":"mg-x-power-sv-r-2005","make":"MG","model":"X Power SV-R","year":"2005","name":"MG X Power SV-R 2005"},{"id":"mini-cooper-s-1965","make":"Mini","model":"Cooper S","year":"1965","name":"Mini Cooper S 1965"},{"id":"mini-john-cooper-works-2009","make":"Mini","model":"John Cooper Works","year":"2009","name":"Mini John Cooper Works 2009"},{"id":"mini-john-cooper-works-countryman-all4-2018","make":"Mini","model":"John Cooper Works Countryman All4","year":"2018","name":"Mini John Cooper Works Countryman All4 2018"},{"id":"mini-john-cooper-works-gp-2012","make":"Mini","model":"John Cooper Works GP","year":"2012","name":"Mini John Cooper Works GP 2012"},{"id":"mini-john-cooper-works-gp-2021","make":"Mini","model":"John Cooper Works GP","year":"2021","name":"Mini John Cooper Works GP 2021"},{"id":"mini-x-raid-all4-racing-countryman-2013","make":"Mini","model":"X-Raid All4 Racing Countryman","year":"2013","name":"Mini X-Raid All4 Racing Countryman 2013"},{"id":"mini-x-raid-john-cooper-works-buggy-2018","make":"Mini","model":"X-Raid John Cooper Works Buggy","year":"2018","name":"Mini X-Raid John Cooper Works Buggy 2018"},{"id":"mitsubishi-eclipse-gsx-1995","make":"Mitsubishi","model":"Eclipse GSX","year":"1995","name":"Mitsubishi Eclipse GSX 1995"},{"id":"mitsubishi-gto-1997","make":"Mitsubishi","model":"GTO","year":"1997","name":"Mitsubishi GTO 1997"},{"id":"mitsubishi-lancer-evolution-ix-mr-2006","make":"Mitsubishi","model":"Lancer Evolution IX MR","year":"2006","name":"Mitsubishi Lancer Evolution IX MR 2006"},{"id":"mitsubishi-lancer-evolution-vi-gsr-1999","make":"Mitsubishi","model":"Lancer Evolution VI GSR","year":"1999","name":"Mitsubishi Lancer Evolution VI GSR 1999"},{"id":"mitsubishi-lancer-evolution-viii-mr-2004","make":"Mitsubishi","model":"Lancer Evolution VIII MR","year":"2004","name":"Mitsubishi Lancer Evolution VIII MR 2004"},{"id":"mitsubishi-lancer-evolution-x-gsr-2008","make":"Mitsubishi","model":"Lancer Evolution X GSR","year":"2008","name":"Mitsubishi Lancer Evolution X GSR 2008"},{"id":"mitsubishi-lancer-evolution-x-gsr-wp-2008","make":"Mitsubishi","model":"Lancer Evolution X GSR WP","year":"2008","name":"Mitsubishi Lancer Evolution X GSR WP 2008"},{"id":"mitsubishi-montero-evolution-1997","make":"Mitsubishi","model":"Montero Evolution","year":"1997","name":"Mitsubishi Montero Evolution 1997"},{"id":"mitsubishi-starion-esi-r-1988","make":"Mitsubishi","model":"Starion ESI-R","year":"1988","name":"Mitsubishi Starion ESI-R 1988"},{"id":"morgan-3-wheeler-2014","make":"Morgan","model":"3 Wheeler","year":"2014","name":"Morgan 3 Wheeler 2014"},{"id":"morris-minor-1000-1953","make":"Morris","model":"Minor 1000","year":"1953","name":"Morris Minor 1000 1953"},{"id":"mosler-mt900s-2010","make":"Mosler","model":"MT900S","year":"2010","name":"Mosler MT900S 2010"},{"id":"napier-napier-railton-1933","make":"Napier","model":"Napier-Railton","year":"1933","name":"Napier Napier-Railton 1933"},{"id":"nissan-240sx-se-1993","make":"Nissan","model":"240SX SE","year":"1993","name":"Nissan 240SX SE 1993"},{"id":"nissan-370z-2010","make":"Nissan","model":"370Z","year":"2010","name":"Nissan 370Z 2010"},{"id":"nissan-370z-nismo-2019","make":"Nissan","model":"370Z Nismo","year":"2019","name":"Nissan 370Z Nismo 2019"},{"id":"nissan-be-1-1987","make":"Nissan","model":"BE-1","year":"1987","name":"Nissan BE-1 1987"},{"id":"nissan-donut-media-350z-high-car-2003","make":"Nissan","model":"Donut Media 350Z 'High Car'","year":"2003","name":"Nissan Donut Media 350Z 'High Car' 2003"},{"id":"nissan-donut-media-350z-low-car-2004","make":"Nissan","model":"Donut Media 350Z 'Low Car'","year":"2004","name":"Nissan Donut Media 350Z 'Low Car' 2004"},{"id":"nissan-fairlady-z","make":"Nissan","model":"Fairlady Z","year":"","name":"Nissan Fairlady Z"},{"id":"nissan-fairlady-z-432-1969","make":"Nissan","model":"Fairlady Z 432","year":"1969","name":"Nissan Fairlady Z 432 1969"},{"id":"nissan-fairlady-z-version-s-twin-turbo-1994","make":"Nissan","model":"Fairlady Z Version S Twin Turbo","year":"1994","name":"Nissan Fairlady Z Version S Twin Turbo 1994"},{"id":"nissan-figaro-1991","make":"Nissan","model":"Figaro","year":"1991","name":"Nissan Figaro 1991"},{"id":"nissan-gt-r-r35-2017","make":"Nissan","model":"GT-R (R35)","year":"2017","name":"Nissan GT-R (R35) 2017"},{"id":"nissan-gt-r-black-edition-r35-2012","make":"Nissan","model":"GT-R Black Edition (R35)","year":"2012","name":"Nissan GT-R Black Edition (R35) 2012"},{"id":"nissan-nismo-gt-r-lm-1995","make":"Nissan","model":"Nismo GT-R LM","year":"1995","name":"Nissan Nismo GT-R LM 1995"},{"id":"nissan-pao-1989","make":"Nissan","model":"Pao","year":"1989","name":"Nissan Pao 1989"},{"id":"nissan-pickup-23-rally-raid-2004","make":"Nissan","model":"Pickup #23 Rally Raid","year":"2004","name":"Nissan Pickup #23 Rally Raid 2004"},{"id":"nissan-pulsar-gti-r-1990","make":"Nissan","model":"Pulsar GTI-R","year":"1990","name":"Nissan Pulsar GTI-R 1990"},{"id":"nissan-r390-gt1-1998","make":"Nissan","model":"R390 (GT1)","year":"1998","name":"Nissan R390 (GT1) 1998"},{"id":"nissan-s-cargo-1989","make":"Nissan","model":"S-Cargo","year":"1989","name":"Nissan S-Cargo 1989"},{"id":"nissan-silvia-club-k-s-1992","make":"Nissan","model":"Silvia Club K's","year":"1992","name":"Nissan Silvia Club K's 1992"},{"id":"nissan-silvia-k-s-1994","make":"Nissan","model":"Silvia K's","year":"1994","name":"Nissan Silvia K's 1994"},{"id":"nissan-silvia-k-s-areo-1998","make":"Nissan","model":"Silvia K's Areo","year":"1998","name":"Nissan Silvia K's Areo 1998"},{"id":"nissan-silvia-spec-r-2000","make":"Nissan","model":"Silvia Spec-R","year":"2000","name":"Nissan Silvia Spec-R 2000"},{"id":"nissan-skyline-200gt-r-1971","make":"Nissan","model":"Skyline 200GT-R","year":"1971","name":"Nissan Skyline 200GT-R 1971"},{"id":"nissan-skyline-gt-r-v-spec-1993","make":"Nissan","model":"Skyline GT-R V-Spec","year":"1993","name":"Nissan Skyline GT-R V-Spec 1993"},{"id":"nissan-skyline-gt-r-v-spec-1997","make":"Nissan","model":"Skyline GT-R V-Spec","year":"1997","name":"Nissan Skyline GT-R V-Spec 1997"},{"id":"nissan-skyline-gt-r-v-spec-ii-2002","make":"Nissan","model":"Skyline GT-R V-Spec II","year":"2002","name":"Nissan Skyline GT-R V-Spec II 2002"},{"id":"nissan-skyline-gts-r-hr31-1987","make":"Nissan","model":"Skyline GTS-R (HR31)","year":"1987","name":"Nissan Skyline GTS-R (HR31) 1987"},{"id":"nissan-skyline-h-t-2000gt-r-1973","make":"Nissan","model":"Skyline H/T 2000GT-R","year":"1973","name":"Nissan Skyline H/T 2000GT-R 1973"},{"id":"nissan-stagea-rs-four-v-1997","make":"Nissan","model":"Stagea RS Four V","year":"1997","name":"Nissan Stagea RS Four V 1997"},{"id":"nissan-titan-warrior-concept-2016","make":"Nissan","model":"Titan Warrior Concept","year":"2016","name":"Nissan Titan Warrior Concept 2016"},{"id":"noble-m400-2006","make":"Noble","model":"M400","year":"2006","name":"Noble M400 2006"},{"id":"oldsmobile-tornado-1966","make":"Oldsmobile","model":"Tornado","year":"1966","name":"Oldsmobile Tornado 1966"},{"id":"opel-manta-400-1984","make":"Opel","model":"Manta 400","year":"1984","name":"Opel Manta 400 1984"},{"id":"pagani-huayra-bc-forza-edition-2016","make":"Pagani","model":"Huayra BC Forza Edition","year":"2016","name":"Pagani Huayra BC Forza Edition 2016"},{"id":"pagani-huayra-r-2021","make":"Pagani","model":"Huayra R","year":"2021","name":"Pagani Huayra R 2021"},{"id":"pagani-zonda-cinque-roadster","make":"Pagani","model":"Zonda Cinque Roadster","year":"","name":"Pagani Zonda Cinque Roadster"},{"id":"pagani-zonda-r-2009","make":"Pagani","model":"Zonda R","year":"2009","name":"Pagani Zonda R 2009"},{"id":"peel-trident-1965","make":"Peel","model":"Trident","year":"1965","name":"Peel Trident 1965"},{"id":"penhall-the-cholla-2011","make":"Penhall","model":"The Cholla","year":"2011","name":"Penhall The Cholla 2011"},{"id":"peugeot-205-rallye-1991","make":"Peugeot","model":"205 Rallye","year":"1991","name":"Peugeot 205 Rallye 1991"},{"id":"peugeot-205-turbo-16-1984","make":"Peugeot","model":"205 Turbo 16","year":"1984","name":"Peugeot 205 Turbo 16 1984"},{"id":"peugeot-207-super-2000","make":"Peugeot","model":"207 Super","year":"2000","name":"Peugeot 207 Super 2000"},{"id":"peugeot-205-rallye-1991","make":"Peugeot","model":"205 Rallye","year":"1991","name":"Peugeot 205 Rallye 1991"},{"id":"plymouth-cuda-426-hemi-1971","make":"Plymouth","model":"Cuda 426 Hemi","year":"1971","name":"Plymouth Cuda 426 Hemi 1971"},{"id":"polaris-rzr-pro-xp-factory-racing-limited-edition-2021","make":"Polaris","model":"RZR PRO XP Factory Racing Limited Edition","year":"2021","name":"Polaris RZR PRO XP Factory Racing Limited Edition 2021"},{"id":"polaris-rzr-xp-1000-eps-2015","make":"Polaris","model":"RZR XP 1000 EPS","year":"2015","name":"Polaris RZR XP 1000 EPS 2015"},{"id":"pontiac-firebird-trans-am-1977","make":"Pontiac","model":"Firebird Trans Am","year":"1977","name":"Pontiac Firebird Trans Am 1977"},{"id":"pontiac-firebird-trans-am-gta-1987","make":"Pontiac","model":"Firebird Trans Am GTA","year":"1987","name":"Pontiac Firebird Trans Am GTA 1987"},{"id":"pontiac-firebird-trans-am-gta-forza-edition-1987","make":"Pontiac","model":"Firebird Trans Am GTA Forza Edition","year":"1987","name":"Pontiac Firebird Trans Am GTA Forza Edition 1987"},{"id":"pontiac-gt0-1965","make":"Pontiac","model":"GT0","year":"1965","name":"Pontiac GT0 1965"},{"id":"porsche-185-959-prodrive-rally-raid-1985","make":"Porsche","model":"#185 959 Prodrive Rally Raid","year":"1985","name":"Porsche #185 959 Prodrive Rally Raid 1985"},{"id":"porsche-23-917-20-1971","make":"Porsche","model":"#23 917/20","year":"1971","name":"Porsche #23 917/20 1971"},{"id":"porsche-3-917-lh-1970","make":"Porsche","model":"#3 917 LH","year":"1970","name":"Porsche #3 917 LH 1970"},{"id":"porsche-65-rothsport-racing-911-desert-flyer-1989","make":"Porsche","model":"#65 Rothsport Racing 911 Desert Flyer","year":"1989","name":"Porsche #65 Rothsport Racing 911 Desert Flyer 1989"},{"id":"porsche-356-a-1600-super-1959","make":"Porsche","model":"356 A 1600 Super","year":"1959","name":"Porsche 356 A 1600 Super 1959"},{"id":"porsche-718-cayman-gt4-rs-2022","make":"Porsche","model":"718 Cayman GT4 RS","year":"2022","name":"Porsche 718 Cayman GT4 RS 2022"},{"id":"porsche-718-cayman-gts-2018","make":"Porsche","model":"718 Cayman GTS","year":"2018","name":"Porsche 718 Cayman GTS 2018"},{"id":"porsche-906-carrera-6-1966","make":"Porsche","model":"906 Carrera 6","year":"1966","name":"Porsche 906 Carrera 6 1966"},{"id":"porsche-911-carrera-rs","make":"Porsche","model":"911 Carrera RS","year":"","name":"Porsche 911 Carrera RS"},{"id":"porsche-911-carrera-s-2019","make":"Porsche","model":"911 Carrera S","year":"2019","name":"Porsche 911 Carrera S 2019"},{"id":"porsche-911-gt2-1995","make":"Porsche","model":"911 GT2","year":"1995","name":"Porsche 911 GT2 1995"},{"id":"porsche-911-gt2-rs-2012","make":"Porsche","model":"911 GT2 RS","year":"2012","name":"Porsche 911 GT2 RS 2012"},{"id":"porsche-911-gt2-rs-2018","make":"Porsche","model":"911 GT2 RS","year":"2018","name":"Porsche 911 GT2 RS 2018"},{"id":"porsche-911-gt3-2004","make":"Porsche","model":"911 GT3","year":"2004","name":"Porsche 911 GT3 2004"},{"id":"porsche-911-gt3-r-2019","make":"Porsche","model":"911 GT3 R","year":"2019","name":"Porsche 911 GT3 R 2019"},{"id":"porsche-911-gt3-rs-2019","make":"Porsche","model":"911 GT3 RS","year":"2019","name":"Porsche 911 GT3 RS 2019"},{"id":"porsche-911-gt3-rs-2019","make":"Porsche","model":"911 GT3 RS","year":"2019","name":"Porsche 911 GT3 RS 2019"},{"id":"porsche-911-gt3-rs-forza-edition-2019","make":"Porsche","model":"911 GT3 RS Forza Edition","year":"2019","name":"Porsche 911 GT3 RS Forza Edition 2019"},{"id":"porsche-911-reimagined-by-singer-dls-1990","make":"Porsche","model":"911 Reimagined By Singer - DLS","year":"1990","name":"Porsche 911 Reimagined By Singer - DLS 1990"},{"id":"porsche-911-speedster","make":"Porsche","model":"911 Speedster","year":"","name":"Porsche 911 Speedster"},{"id":"porsche-911-sport-classic","make":"Porsche","model":"911 Sport Classic","year":"","name":"Porsche 911 Sport Classic"},{"id":"porsche-911-turbo-3-3-1982","make":"Porsche","model":"911 Turbo 3.3","year":"1982","name":"Porsche 911 Turbo 3.3 1982"},{"id":"porsche-911-turbo-s-2014","make":"Porsche","model":"911 Turbo S","year":"2014","name":"Porsche 911 Turbo S 2014"},{"id":"porsche-914-6-1970","make":"Porsche","model":"914/6","year":"1970","name":"Porsche 914/6 1970"},{"id":"porsche-918-spyder","make":"Porsche","model":"918 Spyder","year":"","name":"Porsche 918 Spyder"},{"id":"porsche-944-turbo-1989","make":"Porsche","model":"944 Turbo","year":"1989","name":"Porsche 944 Turbo 1989"},{"id":"porsche-959-1987","make":"Porsche","model":"959","year":"1987","name":"Porsche 959 1987"},{"id":"porsche-968-turbo-s-1993","make":"Porsche","model":"968 Turbo S","year":"1993","name":"Porsche 968 Turbo S 1993"},{"id":"porsche-carrera-gt-2003","make":"Porsche","model":"Carrera GT","year":"2003","name":"Porsche Carrera GT 2003"},{"id":"porsche-cayenne-turbo-2018","make":"Porsche","model":"Cayenne Turbo","year":"2018","name":"Porsche Cayenne Turbo 2018"},{"id":"porsche-cayman-gt4-2016","make":"Porsche","model":"Cayman GT4","year":"2016","name":"Porsche Cayman GT4 2016"},{"id":"porsche-cayman-gts-2015","make":"Porsche","model":"Cayman GTS","year":"2015","name":"Porsche Cayman GTS 2015"},{"id":"porsche-macan-lpr-rally-raid-2018","make":"Porsche","model":"Macan LPR Rally Raid","year":"2018","name":"Porsche Macan LPR Rally Raid 2018"},{"id":"porsche-macan-turbo-2019","make":"Porsche","model":"Macan Turbo","year":"2019","name":"Porsche Macan Turbo 2019"},{"id":"porsche-panamera-turbo-2017","make":"Porsche","model":"Panamera Turbo","year":"2017","name":"Porsche Panamera Turbo 2017"},{"id":"porsche-taycan-turbo-s","make":"Porsche","model":"Taycan Turbo S","year":"","name":"Porsche Taycan Turbo S"},{"id":"porsche-taycan-turbo-s-wp","make":"Porsche","model":"Taycan Turbo S WP","year":"","name":"Porsche Taycan Turbo S WP"},{"id":"porsche-718-cayman-gt4-rs-2022","make":"Porsche","model":"718 Cayman GT4 RS","year":"2022","name":"Porsche 718 Cayman GT4 RS 2022"},{"id":"radical-rxc-turbo-2015","make":"Radical","model":"RXC Turbo","year":"2015","name":"Radical RXC Turbo 2015"},{"id":"ram-2500-power-wagon-2017","make":"RAM","model":"2500 Power Wagon","year":"2017","name":"RAM 2500 Power Wagon 2017"},{"id":"reliant-supervan-iii-1972","make":"Reliant","model":"Supervan III","year":"1972","name":"Reliant Supervan III 1972"},{"id":"renault-4l-export","make":"Renault","model":"4L Export","year":"","name":"Renault 4L Export"},{"id":"renault-5-turbo-1980","make":"Renault","model":"5 Turbo","year":"1980","name":"Renault 5 Turbo 1980"},{"id":"renault-8-gordini-1967","make":"Renault","model":"8 Gordini","year":"1967","name":"Renault 8 Gordini 1967"},{"id":"renault-clio-r-s-200-edc-2013","make":"Renault","model":"Clio R.S. 200 EDC","year":"2013","name":"Renault Clio R.S. 200 EDC 2013"},{"id":"renault-clio-williams-1993","make":"Renault","model":"Clio Williams","year":"1993","name":"Renault Clio Williams 1993"},{"id":"renault-megane-r-s-2018","make":"Renault","model":"Megane R.S.","year":"2018","name":"Renault Megane R.S. 2018"},{"id":"renault-megane-r26-r-2008","make":"Renault","model":"Megane R26 R","year":"2008","name":"Renault Megane R26 R 2008"},{"id":"rimac-concept-two-2019","make":"Rimac","model":"Concept Two","year":"2019","name":"Rimac Concept Two 2019"},{"id":"rj-anderson-37-polaris-rzr-pro-4-truck-2021","make":"RJ Anderson","model":"#37 Polaris RZR Pro 4 Truck","year":"2021","name":"RJ Anderson #37 Polaris RZR Pro 4 Truck 2021"},{"id":"rj-anderson-no-37-polaris-rzr-rockstar-energy-pro-2-truck-2016","make":"RJ Anderson","model":"No.37 Polaris Rzr-Rockstar Energy Pro 2 Truck","year":"2016","name":"RJ Anderson No.37 Polaris Rzr-Rockstar Energy Pro 2 Truck 2016"},{"id":"saleen-s1-2018","make":"Saleen","model":"S1","year":"2018","name":"Saleen S1 2018"},{"id":"saleen-s7-2004","make":"Saleen","model":"S7","year":"2004","name":"Saleen S7 2004"},{"id":"saleen-s7-lm-2017","make":"Saleen","model":"S7 LM","year":"2017","name":"Saleen S7 LM 2017"},{"id":"saleen-sportruck-xr-black-label-2020","make":"Saleen","model":"Sportruck XR Black Label","year":"2020","name":"Saleen Sportruck XR Black Label 2020"},{"id":"shelby-cobra-427-s-c-1965","make":"Shelby","model":"Cobra 427 S/C","year":"1965","name":"Shelby Cobra 427 S/C 1965"},{"id":"shelby-cobra-daytona-coupe-1965","make":"Shelby","model":"Cobra Daytona Coupe","year":"1965","name":"Shelby Cobra Daytona Coupe 1965"},{"id":"shelby-gt-500-1967","make":"Shelby","model":"GT 500","year":"1967","name":"Shelby GT 500 1967"},{"id":"sierra-cars-rx3-2021","make":"Sierra Cars","model":"RX3","year":"2021","name":"Sierra Cars RX3 2021"},{"id":"subaru-brz-2013","make":"Subaru","model":"BRZ","year":"2013","name":"Subaru BRZ 2013"},{"id":"subaru-impreza-22b-sti-version-1998","make":"Subaru","model":"Impreza 22B-STI Version","year":"1998","name":"Subaru Impreza 22B-STI Version 1998"},{"id":"subaru-impreza-wrx-sti-2004","make":"Subaru","model":"Impreza WRX STI","year":"2004","name":"Subaru Impreza WRX STI 2004"},{"id":"subaru-impreza-wrx-sti-2005","make":"Subaru","model":"Impreza WRX STI","year":"2005","name":"Subaru Impreza WRX STI 2005"},{"id":"subaru-impreza-wrx-sti-2008","make":"Subaru","model":"Impreza WRX STI","year":"2008","name":"Subaru Impreza WRX STI 2008"},{"id":"subaru-sti-s209-2019","make":"Subaru","model":"STI S209","year":"2019","name":"Subaru STI S209 2019"},{"id":"subaru-wrx-sti-2011","make":"Subaru","model":"WRX STI","year":"2011","name":"Subaru WRX STI 2011"},{"id":"subaru-wrx-sti-2015","make":"Subaru","model":"WRX STI","year":"2015","name":"Subaru WRX STI 2015"},{"id":"toyota-1-t100-baja-truck","make":"Toyota","model":"#1 T100 Baja Truck","year":"","name":"Toyota #1 T100 Baja Truck"},{"id":"toyota-2000gt-1969","make":"Toyota","model":"2000GT","year":"1969","name":"Toyota 2000GT 1969"},{"id":"toyota-86-2013","make":"Toyota","model":"86.","year":"2013","name":"Toyota 86. 2013"},{"id":"toyota-celica-gt-1974","make":"Toyota","model":"Celica GT","year":"1974","name":"Toyota Celica GT 1974"},{"id":"toyota-celica-gt-four-rc-st185-1992","make":"Toyota","model":"Celica GT-Four RC ST185","year":"1992","name":"Toyota Celica GT-Four RC ST185 1992"},{"id":"toyota-celica-gt-four-st205-1994","make":"Toyota","model":"Celica GT-Four ST205","year":"1994","name":"Toyota Celica GT-Four ST205 1994"},{"id":"toyota-celica-sport-speciality-ii-2003","make":"Toyota","model":"Celica Sport Speciality II","year":"2003","name":"Toyota Celica Sport Speciality II 2003"},{"id":"toyota-fj40-1979","make":"Toyota","model":"FJ40","year":"1979","name":"Toyota FJ40 1979"},{"id":"toyota-gr-supra-2020","make":"Toyota","model":"GR Supra","year":"2020","name":"Toyota GR Supra 2020"},{"id":"toyota-mr2-sc-1989","make":"Toyota","model":"MR2 SC","year":"1989","name":"Toyota MR2 SC 1989"},{"id":"toyota-sera-1991","make":"Toyota","model":"Sera","year":"1991","name":"Toyota Sera 1991"},{"id":"toyota-sprinter-trueno-gt-apex-1985","make":"Toyota","model":"Sprinter Trueno GT Apex","year":"1985","name":"Toyota Sprinter Trueno GT Apex 1985"},{"id":"toyota-supra-2-0-gt-1992","make":"Toyota","model":"Supra 2.0 GT","year":"1992","name":"Toyota Supra 2.0 GT 1992"},{"id":"toyota-supra-rz-1998","make":"Toyota","model":"Supra RZ","year":"1998","name":"Toyota Supra RZ 1998"},{"id":"toyota-supra-rz-wp-1998","make":"Toyota","model":"Supra RZ WP","year":"1998","name":"Toyota Supra RZ WP 1998"},{"id":"toyota-tacoma-trd-pro-2019","make":"Toyota","model":"Tacoma TRD Pro","year":"2019","name":"Toyota Tacoma TRD Pro 2019"},{"id":"toyota-tundra-trd-pro-2020","make":"Toyota","model":"Tundra TRD Pro","year":"2020","name":"Toyota Tundra TRD Pro 2020"},{"id":"tvr-cerbera-speed-12-1998","make":"TVR","model":"Cerbera Speed 12","year":"1998","name":"TVR Cerbera Speed 12 1998"},{"id":"tvr-griffith-2018","make":"TVR","model":"Griffith","year":"2018","name":"TVR Griffith 2018"},{"id":"tvr-sagaris-2005","make":"TVR","model":"Sagaris","year":"2005","name":"TVR Sagaris 2005"},{"id":"ultima-evolution-coupe-1020-2015","make":"Ultima","model":"Evolution Coupe 1020","year":"2015","name":"Ultima Evolution Coupe 1020 2015"},{"id":"universal-studios-back-to-the-future-time-machine-1-1981","make":"Universal","model":"Studios Back To The Future Time Machine 1","year":"1981","name":"Universal Studios Back To The Future Time Machine 1 1981"},{"id":"universal-studios-back-to-the-future-time-machine-2-1981","make":"Universal","model":"Studios Back To The Future Time Machine 2","year":"1981","name":"Universal Studios Back To The Future Time Machine 2 1981"},{"id":"universal-studios-back-to-the-future-time-machine-3-1981","make":"Universal","model":"Studios Back To The Future Time Machine 3","year":"1981","name":"Universal Studios Back To The Future Time Machine 3 1981"},{"id":"universal-studios-jeep-wrangler-sahara-jurassic-park-1992","make":"Universal","model":"Studios Jeep Wrangler Sahara 'Jurassic Park'","year":"1992","name":"Universal Studios Jeep Wrangler Sahara 'Jurassic Park' 1992"},{"id":"universal-studios-k-i-t-t-1982","make":"Universal","model":"Studios K.I.T.T.","year":"1982","name":"Universal Studios K.I.T.T. 1982"},{"id":"vauxhall-corsa-vxr-2016","make":"Vauxhall","model":"Corsa VXR","year":"2016","name":"Vauxhall Corsa VXR 2016"},{"id":"vauxhall-monaro-vxr-2005","make":"Vauxhall","model":"Monaro VXR","year":"2005","name":"Vauxhall Monaro VXR 2005"},{"id":"volkswagen-1107-desert-dingo-racing-stock-bug-1970","make":"Volkswagen","model":"#1107 Desert Dingo Racing Stock Bug","year":"1970","name":"Volkswagen #1107 Desert Dingo Racing Stock Bug 1970"},{"id":"volkswagen-beetle-1963","make":"Volkswagen","model":"Beetle","year":"1963","name":"Volkswagen Beetle 1963"},{"id":"volkswagen-class-5-1600-baja-bug","make":"Volkswagen","model":"Class 5/1600 Baja Bug","year":"","name":"Volkswagen Class 5/1600 Baja Bug"},{"id":"volkswagen-corrado-vr6","make":"Volkswagen","model":"Corrado VR6","year":"","name":"Volkswagen Corrado VR6"},{"id":"volkswagen-golf-gti-16v-mk2-1992","make":"Volkswagen","model":"Golf GTI 16V MK2","year":"1992","name":"Volkswagen Golf GTI 16V MK2 1992"},{"id":"volkswagen-golf-gti-1983","make":"Volkswagen","model":"Golf GTI","year":"1983","name":"Volkswagen Golf GTI 1983"},{"id":"volkswagen-golf-r-2010","make":"Volkswagen","model":"Golf R","year":"2010","name":"Volkswagen Golf R 2010"},{"id":"volkswagen-golf-r-2014","make":"Volkswagen","model":"Golf R","year":"2014","name":"Volkswagen Golf R 2014"},{"id":"volkswagen-golf-r-2022","make":"Volkswagen","model":"Golf R","year":"2022","name":"Volkswagen Golf R 2022"},{"id":"volkswagen-golf-r32-2003","make":"Volkswagen","model":"Golf R32","year":"2003","name":"Volkswagen Golf R32 2003"},{"id":"volkswagen-golf-r-2021","make":"Volkswagen","model":"Golf-R","year":"2021","name":"Volkswagen Golf-R 2021"},{"id":"volkswagen-gti-vr6-mk3-1986","make":"Volkswagen","model":"GTI VR6 MK3","year":"1986","name":"Volkswagen GTI VR6 MK3 1986"},{"id":"volkswagen-no-34-andretti-beetle-2017","make":"Volkswagen","model":"No. 34 Andretti Beetle","year":"2017","name":"Volkswagen No. 34 Andretti Beetle 2017"},{"id":"volkswagen-pickup-lx","make":"Volkswagen","model":"Pickup LX","year":"","name":"Volkswagen Pickup LX"},{"id":"volkswagen-santana-2012","make":"Volkswagen","model":"Santana","year":"2012","name":"Volkswagen Santana 2012"},{"id":"volkswagen-scirocco-r-2011","make":"Volkswagen","model":"Scirocco R","year":"2011","name":"Volkswagen Scirocco R 2011"},{"id":"volkswagen-scirocco-s-1981","make":"Volkswagen","model":"Scirocco S","year":"1981","name":"Volkswagen Scirocco S 1981"},{"id":"volkswagen-type-2-de-luxe-1963","make":"Volkswagen","model":"Type 2 De Luxe","year":"1963","name":"Volkswagen Type 2 De Luxe 1963"},{"id":"volvo-242-turbo-evolution-1983","make":"Volvo","model":"242 Turbo Evolution","year":"1983","name":"Volvo 242 Turbo Evolution 1983"},{"id":"volvo-850-r-1997","make":"Volvo","model":"850 R","year":"1997","name":"Volvo 850 R 1997"},{"id":"volvo-v60-polestar-2015","make":"Volvo","model":"V60 Polestar","year":"2015","name":"Volvo V60 Polestar 2015"},{"id":"vuhl-05rr-2017","make":"Vuhl","model":"05RR","year":"2017","name":"Vuhl 05RR 2017"},{"id":"vw-golf-r-2022","make":"VW","model":"Golf R","year":"2022","name":"VW Golf R 2022"},{"id":"willys-mb-jeep-1945","make":"Willys","model":"MB Jeep","year":"1945","name":"Willys MB Jeep 1945"},{"id":"wuling-hongguang-mini-ec-macron-2022","make":"Wuling","model":"Hongguang Mini EC Macron","year":"2022","name":"Wuling Hongguang Mini EC Macron 2022"},{"id":"xpeng-p7-2020","make":"XPeng","model":"P7","year":"2020","name":"XPeng P7 2020"},{"id":"zenvo-tsr-s-2019","make":"Zenvo","model":"TSR-S","year":"2019","name":"Zenvo TSR-S 2019"}],"events":[{"id":"drag","name":"Drag","type":"time"},{"id":"long-jump","name":"Long Jump","type":"distance"},{"id":"marathon","name":"Marathon","type":"time"},{"id":"goliath","name":"Goliath","type":"time"},{"id":"colossus","name":"Colossus","type":"time"},{"id":"gauntlet","name":"Gauntlet","type":"time"},{"id":"titan","name":"Titan","type":"time"}]};
const STORE='RaceHub_v4_1_director_edition';
let state=null;
let currentScreen='festival';
let currentEventId='drag';
let eventTab='waiting';
let garageMake='All';
let garageSearch='';
let selectedRun=null;

const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const carName=c=>`${c.make} ${c.model}${c.year?' '+c.year:''}`.replace(/\s+/g,' ').trim();
const eventById=id=>state.events.find(e=>e.id===id)||state.events[0];
const carById=id=>state.cars.find(c=>c.id===id);
const isLong=id=>eventById(id).type==='distance';

function freshState(){return {version:'3.5',cars:[...SEED.cars],events:[...SEED.events],results:[],history:[],recordHistory:[],lastRun:null,currentEventId:'drag',settings:{sound:true,confetti:true,vibrate:true}}}
function load(){try{const raw=JSON.parse(localStorage.getItem(STORE)||'null');if(raw&&raw.cars&&raw.events){raw.settings=Object.assign({sound:true,confetti:true,vibrate:true},raw.settings||{});raw.recordHistory=raw.recordHistory||[];return raw;}}catch(e){} return freshState();}
function save(){localStorage.setItem(STORE,JSON.stringify(state));}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
function show(screen){currentScreen=screen;document.querySelectorAll('.screen').forEach(s=>s.classList.add('hidden'));$(screen).classList.remove('hidden');document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.screen===screen));render(screen);window.scrollTo(0,0)}
document.querySelectorAll('.nav button').forEach(b=>b.addEventListener('click',()=>show(b.dataset.screen)));

function parseResult(eventId,raw){
 raw=String(raw||'').trim(); if(!raw)return NaN;
 if(isLong(eventId)) return Number(raw.replace(/[^0-9.]/g,''));
 const ev=eventById(eventId);
 if(ev.name==='Drag'){ if(raw.includes('.'))return Number(raw.replace(/[^0-9.]/g,'')); let d=raw.replace(/\D/g,''); if(d.length>3)return Number(d.slice(0,-3)+'.'+d.slice(-3)); return Number(d); }
 if(raw.includes(':')){let p=raw.split(':'); if(p.length!==2)return NaN; return Number(p[0])*60+Number(p[1]);}
 let d=raw.replace(/\D/g,''); if(d.length<4)return Number(d);
 let ms=d.slice(-3), before=d.slice(0,-3), sec=before.slice(-2), min=before.slice(0,-2)||'0';
 return Number(min)*60+Number(sec+'.'+ms);
}
function fmt(eventId,v){ if(v==null||!isFinite(v))return '—'; if(isLong(eventId))return Number(v).toLocaleString(undefined,{maximumFractionDigits:2})+' ft'; let m=Math.floor(v/60), s=(v-m*60).toFixed(3).padStart(6,'0'); return m>0?String(m).padStart(2,'0')+':'+s:s+'s'; }

function bestRows(eventId){
 const map={};
 state.results.filter(r=>r.eventId===eventId).forEach(r=>{ if(!map[r.carId] || (isLong(eventId)?r.value>map[r.carId].value:r.value<map[r.carId].value)) map[r.carId]=r; });
 return Object.values(map).sort((a,b)=>isLong(eventId)?b.value-a.value:a.value-b.value);
}
function eventStats(eventId){const rows=bestRows(eventId), total=state.cars.length;return {done:rows.length,total,waiting:total-rows.length,pct:total?Math.round(rows.length/total*100):0,leader:rows[0]||null,rows}}
function completedSet(eventId){return new Set(bestRows(eventId).map(r=>r.carId));}
function waitingCars(eventId){const done=completedSet(eventId);return state.cars.filter(c=>!done.has(c.id));}
function carCompletedEvents(carId){
 const set=new Set();
 state.results.forEach(r=>{if(r.carId===carId)set.add(r.eventId)});
 return set;
}
function carIsComplete(carId){return carCompletedEvents(carId).size>=state.events.length}
function unfinishedCars(){return state.cars.filter(c=>!carIsComplete(c.id))}
function nextEventForCar(carId){
 const done=carCompletedEvents(carId);
 return state.events.find(e=>!done.has(e.id)) || null;
}
function currentCar(){
  if(!state.currentCarId)return null;
  const c=carById(state.currentCarId);
  if(!c || carIsComplete(c.id))return null;
  return c;
}
function continueCurrentCar(){
  const c=currentCar();
  if(!c){startRaceDirector();return;}
  const ev=nextEventForCar(c.id);
  if(!ev){startRaceDirector();return;}
  selectedRun={eventId:ev.id,carId:c.id};
  currentEventId=ev.id;
  state.currentEventId=ev.id;
  save();
  eventTab='add';
  show('event');
}

function allPendingRuns(){
 let total=state.events.length*state.cars.length;
 let done=0;
 state.cars.forEach(c=>done+=carCompletedEvents(c.id).size);
 return {total,done,remaining:total-done};
}
function chooseRandomCar(){
 let cars=unfinishedCars();
 if(!cars.length)return null;
 let last=state.lastCarId||null;
 let pool=cars.filter(c=>c.id!==last);
 if(!pool.length)pool=cars;
 return pool[Math.floor(Math.random()*pool.length)];
}
function startRaceDirector(){
 const car=chooseRandomCar();
 if(!car){toast('All cars complete');return;}
 const ev=nextEventForCar(car.id);
 if(!ev){toast('Car already complete');return;}
 selectedRun={eventId:ev.id,carId:car.id};
 currentEventId=ev.id;
 state.currentEventId=ev.id;
 state.lastCarId=car.id;
 state.currentCarId=car.id;
 save();
 eventTab='add';
 show('event');
}
function openEvent(eventId,tab='waiting'){currentEventId=eventId;state.currentEventId=eventId;save();eventTab=tab;selectedRun=null;show('event')}

function render(screen){ if(screen==='festival')renderFestival(); if(screen==='events')renderEvents(); if(screen==='event')renderEvent(); if(screen==='garage')renderGarage(); if(screen==='more')renderMore(); }


function currentCarProgress(){
  const c=currentCar();
  if(!c)return null;
  const done=carCompletedEvents(c.id).size;
  const next=nextEventForCar(c.id);
  return {car:c,done,next,complete:done>=state.events.length};
}

const directorLines=[
  'Good evening, drivers...',
  'The garage has spoken...',
  'A new challenger approaches...',
  'This should be interesting...',
  'Let’s see what this one can do...',
  'RaceHub is taking control...'
];
function directorSpeak(text){
  const el=$('directorLine');
  if(!el)return;
  el.textContent='';
  let i=0;
  const timer=setInterval(()=>{
    el.textContent += text.charAt(i++);
    if(i>=text.length)clearInterval(timer);
  },26);
}
function directorOverlay(html){
  closeDirector();
  document.body.insertAdjacentHTML('beforeend',`<div id="directorOverlay" class="directorOverlay">${html}</div>`);
}
function closeDirector(){
  const o=$('directorOverlay');
  if(o)o.remove();
}
function skipDirectorToRun(eventId,carId){
  closeDirector();
  selectedRun={eventId,carId};
  currentEventId=eventId;
  state.currentEventId=eventId;
  state.currentCarId=carId;
  save();
  eventTab='add';
  show('event');
}
function beginDirectorShow(forceNew=false){
  const c=currentCar();
  if(c && !forceNew){continueCurrentCar();return;}
  if(forceNew){state.currentCarId=null;save();}
  const car=chooseRandomCar();
  if(!car){toast('All cars complete');return;}
  const ev=nextEventForCar(car.id);
  if(!ev){toast('Car already complete');return;}
  state.lastCarId=car.id;
  state.currentCarId=car.id;
  state.currentEventId=ev.id;
  save();
  const line=directorLines[Math.floor(Math.random()*directorLines.length)];
  directorOverlay(`<button class="skipBtn" onclick="skipDirectorToRun('${ev.id}','${car.id}')">Skip</button><div class="directorCard">
    <div style="font-size:54px">🏁</div>
    <div class="directorTitle">RACEHUB</div>
    <div class="directorLine" id="directorLine">Race Director Initialising...</div>
    <div class="checkList">
      ✓ Garage Connected<br>
      ✓ ${state.cars.length} Cars Ready<br>
      ✓ ${state.events.length} Events Loaded<br>
      ✓ Record Database Loaded<br>
      ✓ Race Director Online
    </div>
  </div>`);
  setTimeout(()=>directorSpeak(line),600);
  setTimeout(()=>directorCarSlot(car,ev),2300);
}
function directorCarSlot(car,ev){
  const names=state.cars.slice(0,80).map(carName);
  directorOverlay(`<button class="skipBtn" onclick="skipDirectorToRun('${ev.id}','${car.id}')">Skip</button><div class="directorCard">
    <div class="directorLine">Tonight's randomly selected car is...</div>
    <div class="slotBox"><div class="slotText" id="slotText">Selecting...</div></div>
  </div>`);
  let i=0;
  const slot=$('slotText');
  const spin=setInterval(()=>{
    if(slot)slot.textContent=names[Math.floor(Math.random()*names.length)];
    i++;
    if(i>22){
      clearInterval(spin);
      if(slot)slot.textContent=carName(car);
      if(navigator.vibrate)navigator.vibrate(60);
      setTimeout(()=>directorEventReveal(car,ev),900);
    }
  },80);
}
function directorEventReveal(car,ev){
  directorOverlay(`<button class="skipBtn" onclick="skipDirectorToRun('${ev.id}','${car.id}')">Skip</button><div class="directorCard">
    <div class="directorLine">Your opening challenge is...</div>
    <div class="directorBig">🚗 ${esc(carName(car))}</div>
    <div class="directorTitle">🏁 ${esc(ev.name)}</div>
    <div class="directorActions">
      <button class="btn bigStart" onclick="skipDirectorToRun('${ev.id}','${car.id}')">▶ Start Event</button>
    </div>
  </div>`);
}
function directorNextEvent(carId,eventId){
  const car=carById(carId), ev=eventById(eventId);
  directorOverlay(`<button class="skipBtn" onclick="skipDirectorToRun('${eventId}','${carId}')">Skip</button><div class="directorCard">
    <div style="font-size:44px">✅</div>
    <div class="directorLine">Result accepted.</div>
    <div class="directorLine">Preparing next challenge...</div>
    <div class="directorBig">🚗 ${esc(carName(car))}</div>
    <div class="directorTitle">🏁 ${esc(ev.name)}</div>
    <div class="directorActions"><button class="btn bigStart" onclick="skipDirectorToRun('${eventId}','${carId}')">▶ Start ${esc(ev.name)}</button></div>
  </div>`);
}

function startRaceNight(){
  const c=currentCar();
  if(c){continueCurrentCar();return;}
  startRaceDirector();
}
function carCompletionStats(carId){
  const rows=state.results.filter(r=>r.carId===carId);
  let records=0,bestFinish=null;
  state.events.forEach(ev=>{
    const board=bestRows(ev.id);
    const pos=board.findIndex(r=>r.carId===carId);
    if(pos===0)records++;
    if(pos>=0 && (bestFinish==null || pos<bestFinish.pos)) bestFinish={pos,event:ev.name};
  });
  return {results:rows.length,records,bestFinish};
}
function showCarComplete(carId){
  const car=carById(carId), stats=carCompletionStats(carId);
  const best=stats.bestFinish?`${stats.bestFinish.pos+1}${['st','nd','rd'][stats.bestFinish.pos]||'th'} in ${stats.bestFinish.event}`:'—';
  $('event').innerHTML=`<div class="card"><h2>🏁 Race Night Complete</h2>
    <div class="completedCar"><h3>Car Completed</h3><h2>${esc(carName(car))}</h2><p class="small">All 7 events complete</p></div>
    <div class="grid"><div class="resultBox"><div class="legacyBig">${stats.records}</div><div class="small">event records held</div></div><div class="resultBox"><div class="legacyBig">${best}</div><div class="small">best finish</div></div></div>
    <button class="btn bigStart" onclick="beginDirectorShow(true)">🎲 Pick Next Random Car</button>
    <button class="btn secondary" onclick="show('festival')">Back to Festival</button>
  </div>`;
}

function renderFestival(){
 const runStats=allPendingRuns(), total=runStats.total, remaining=runStats.remaining, done=runStats.done;
 const ev=eventById(state.currentEventId||'drag'), st=eventStats(ev.id), leader=st.leader;
 const next=waitingCars(ev.id)[0];
 const cc=currentCar();
 const ccDone=cc?carCompletedEvents(cc.id).size:0;
 const ccNext=cc?nextEventForCar(cc.id):null;
 $('festival').innerHTML=`<div class="card"><h2>Race Night Dashboard</h2>${cc?`<div class="raceNightPanel"><h2>▶️ Race Night In Progress</h2><p><b>${esc(carName(cc))}</b></p><div class="progress"><div class="bar" style="width:${Math.round(ccDone/7*100)}%"></div></div><p class="small">${ccDone}/7 events complete · Next: ${ccNext?esc(ccNext.name):'—'}</p><button class="btn bigStart" onclick="continueCurrentCar()">Continue Current Car</button><button class="btn secondary" onclick="beginDirectorShow(true)">🎲 Draw Different Random Car</button></div>`:''}<div class="raceDirector"><h2>🏁 Race Night Mode</h2><p class="small">RaceHub chooses a random car, then guides it through all 7 events.</p><button class="btn bigStart" onclick="beginDirectorShow()">🏁 Start Race Night</button></div>
 
${(()=>{const leg=legendaryRecord(); if(!leg)return ''; const ev=eventById(leg.eventId), car=carById(leg.carId); return `<div class="legacyCard"><h3>👑 Legendary Record</h3><b>${esc(ev.name)}</b><br>${esc(car?carName(car):leg.carId)}<br><span class="small">${esc(daysText(leg.held))}</span></div>`})()}
<div class="grid"><div class="resultBox"><div class="small">Runs done</div><h2>${done}</h2></div><div class="resultBox"><div class="small">Runs left</div><h2>${remaining}</h2></div></div>
 <h3>Current Event</h3><div class="eventCard" onclick="openEvent('${ev.id}','waiting')"><div class="eventTop"><b>🏁 ${esc(ev.name)}</b><span class="badge">${st.done}/${st.total}</span></div><div class="progress"><div class="bar" style="width:${st.pct}%"></div></div><div class="small">${leader?'Record: '+esc(fmt(ev.id,leader.value))+' — '+esc(carName(carById(leader.carId))):'No record yet'}</div><div class="small">Next waiting: ${next?esc(carName(next)):'—'}</div></div>
 </div>`;
}

function renderEvents(){
 $('events').innerHTML=`<div class="card"><h2>Events</h2><p class="small">Open any event to add results, view the leaderboard or see waiting cars.</p>${state.events.map(e=>{let s=eventStats(e.id), leader=s.leader;return `<div class="eventCard" onclick="openEvent('${e.id}','waiting')"><div class="eventTop"><b>🏁 ${esc(e.name)}</b><span class="badge">${s.done}/${s.total}</span></div><div class="progress"><div class="bar" style="width:${s.pct}%"></div></div><div class="small">${leader?'Record: '+esc(fmt(e.id,leader.value))+' — '+esc(carName(carById(leader.carId))):'No record yet'}</div></div>`}).join('')}</div>`;
}

function podium(rows){return `<div class="podium"><div class="pod">${rows[1]?`🥈<br><b>${esc(carName(carById(rows[1].carId)))}</b><br>${esc(fmt(rows[1].eventId,rows[1].value))}`:''}</div><div class="pod first">${rows[0]?`🥇<br><b>${esc(carName(carById(rows[0].carId)))}</b><br>${esc(fmt(rows[0].eventId,rows[0].value))}`:''}</div><div class="pod">${rows[2]?`🥉<br><b>${esc(carName(carById(rows[2].carId)))}</b><br>${esc(fmt(rows[2].eventId,rows[2].value))}`:''}</div></div>`}

function renderEvent(){
 const ev=eventById(currentEventId), st=eventStats(ev.id);
 const tabs=`<div class="grid"><button class="btn secondary" onclick="eventTab='waiting';renderEvent()">Waiting</button><button class="btn secondary" onclick="eventTab='add';selectedRun=null;renderEvent()">Add Result</button></div><button class="btn secondary" onclick="eventTab='leaderboard';renderEvent()">Leaderboard</button>`;
 let body='';
 if(eventTab==='waiting'){
   const list=waitingCars(ev.id);
   body=`<h3>Waiting Cars</h3><p class="small">${list.length} cars still waiting.</p>${list.slice(0,140).map(c=>`<div class="row"><div class="rank">⏳</div><div class="grow">${esc(carName(c))}</div><button class="chip" onclick="selectedRun={eventId:'${ev.id}',carId:'${c.id}'};eventTab='add';renderEvent()">Run</button></div>`).join('')}${list.length>140?'<p class="small">Showing first 140 waiting cars.</p>':''}`;
 }
 if(eventTab==='leaderboard'){
   const rows=st.rows;
   body=`<h3>Leaderboard</h3>${rows.length?podium(rows):'<div class="empty">No results yet.</div>'}${rows.map((r,i)=>`<div class="row"><div class="rank">${i+1}</div><div class="grow">${esc(carName(carById(r.carId)))}<br><span class="small">${esc(fmt(ev.id,r.value))}</span></div><button class="chip" onclick="editResult('${r.id}')">Edit</button><button class="chip" onclick="deleteResult('${r.id}')">Delete</button></div>`).join('')}`;
 }
 if(eventTab==='add'){
   const chosen=selectedRun&&selectedRun.eventId===ev.id?carById(selectedRun.carId):waitingCars(ev.id)[0];
   body=`<h3>Add Result</h3>${selectedRun?`<div class="resultBox"><b>Selected Car</b><br>${esc(carName(chosen))}</div>`:''}<label>Car</label><select id="carSelect" ${selectedRun?'disabled':''}>${waitingCars(ev.id).map(c=>`<option value="${c.id}" ${chosen&&chosen.id===c.id?'selected':''}>${esc(carName(c))}</option>`).join('')}</select><label>${isLong(ev.id)?'Distance':'Time'}</label><input id="resultInput" inputmode="numeric" pattern="[0-9.]*" placeholder="${isLong(ev.id)?'1448.31':(ev.name==='Drag'?'27494 → 27.494':'924766 → 09:24.766')}"><p class="small">${isLong(ev.id)?'Long Jump: enter distance.':'Numbers only works on Samsung keyboards.'}</p><button class="btn" onclick="saveResult()">Save Result</button>${selectedRun?'<button class="btn secondary" onclick="startRaceDirector()">Skip Car / Pick Another</button>':''}`;
 }
 $('event').innerHTML=`<a class="small" onclick="show('events')">← Events</a><div class="card"><h2>🏁 ${esc(ev.name)}</h2><div class="progress"><div class="bar" style="width:${st.pct}%"></div></div><p class="small">${st.done}/${st.total} complete · ${st.waiting} waiting</p>${tabs}${body}</div>`;
}



function playRecordSound(){
  if(!state.settings || !state.settings.sound) return;
  try{
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const now = ctx.currentTime;
    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.exponentialRampToValueAtTime(0.18, now+0.03);
    master.gain.exponentialRampToValueAtTime(0.0001, now+1.15);
    master.connect(ctx.destination);

    function tone(freq, start, dur, type='sine'){
      const o=ctx.createOscillator();
      const g=ctx.createGain();
      o.type=type;
      o.frequency.setValueAtTime(freq, now+start);
      g.gain.setValueAtTime(0.0001, now+start);
      g.gain.exponentialRampToValueAtTime(0.85, now+start+0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, now+start+dur);
      o.connect(g); g.connect(master);
      o.start(now+start); o.stop(now+start+dur+0.04);
    }
    // short achievement fanfare
    tone(392,0.00,0.18,'triangle');
    tone(523.25,0.16,0.18,'triangle');
    tone(659.25,0.32,0.22,'triangle');
    tone(783.99,0.54,0.32,'triangle');
    tone(1046.5,0.78,0.34,'sine');
  }catch(e){}
}
function vibrateRecord(){
  if(state.settings && state.settings.vibrate && navigator.vibrate) navigator.vibrate([80,40,120,40,180]);
}

function launchConfetti(){
  if(state.settings && state.settings.confetti===false) return;
  const overlay=document.getElementById('celebrationOverlay');
  if(!overlay)return;
  const colors=['#ff2bd6','#7b2cff','#34d7ff','#ffd84d','#ff8a00','#ffffff'];
  for(let i=0;i<140;i++){
    const p=document.createElement('div');
    p.className='confettiPiece';
    p.style.left=(Math.random()*100)+'vw';
    p.style.top=(-20-Math.random()*80)+'px';
    p.style.background=colors[Math.floor(Math.random()*colors.length)];
    p.style.animationDelay=(Math.random()*0.5)+'s';
    p.style.animationDuration=(2.0+Math.random()*2.0)+'s';
    p.style.width=(6+Math.random()*8)+'px';
    p.style.height=(10+Math.random()*14)+'px';
    p.style.transform='rotate('+Math.floor(Math.random()*360)+'deg)';
    overlay.appendChild(p);
  }
}

function daysBetween(a,b){
  if(!a||!b)return null;
  const d1=new Date(a), d2=new Date(b);
  if(isNaN(d1)||isNaN(d2))return null;
  return Math.max(0,Math.floor((d2-d1)/86400000));
}
function daysText(days){
  if(days==null)return '';
  if(days===0)return 'Held for today';
  if(days===1)return 'Held for 1 day';
  if(days<365)return `Held for ${days} days`;
  const y=Math.floor(days/365), rem=days%365, m=Math.floor(rem/30);
  return `Held for ${y} year${y>1?'s':''}${m?`, ${m} month${m>1?'s':''}`:''}`;
}
function improvementText(eventId,newValue,oldValue){
  if(oldValue==null||!isFinite(oldValue))return '';
  const diff=isLong(eventId)?newValue-oldValue:oldValue-newValue;
  if(!isFinite(diff))return '';
  if(isLong(eventId))return `${diff.toFixed(2)} ft farther`;
  return `${diff.toFixed(3)} seconds faster`;
}
function latestRecordForEvent(eventId){
  const hist=(state.recordHistory||[]).filter(h=>h.eventId===eventId);
  return hist.length?hist[hist.length-1]:null;
}
function addRecordHistory(eventId,carId,value,previousRecord){
  state.recordHistory=state.recordHistory||[];
  const now=new Date().toISOString();
  const entry={
    id:'rh'+Date.now(),
    eventId,carId,value,date:now,
    previousCarId:previousRecord?previousRecord.carId:null,
    previousValue:previousRecord?previousRecord.value:null,
    previousDate:previousRecord?previousRecord.date:null,
    daysStood:previousRecord?daysBetween(previousRecord.date,now):null,
    improvement:previousRecord?improvementText(eventId,value,previousRecord.value):''
  };
  state.recordHistory.push(entry);
  return entry;
}
function legendaryRecord(){
  const hist=state.recordHistory||[];
  let best=null;
  hist.forEach(h=>{
    const held = h.daysStood!=null ? h.daysStood : daysBetween(h.date,new Date().toISOString());
    if(held!=null && (!best || held>best.held)) best={...h,held};
  });
  return best;
}


function showMiniRecordBanner(data){
  const old=document.getElementById('recordBannerMini');
  if(old)old.remove();
  const parts=['🏆 Record Shattered!'];
  if(data.improvement)parts.push('⚡ '+data.improvement);
  if(data.heldText)parts.push('⏳ '+data.heldText);
  document.body.insertAdjacentHTML('beforeend',`<div id="recordBannerMini" class="recordBannerMini">${esc(parts.join(' • '))}</div>`);
  setTimeout(()=>{
    const b=document.getElementById('recordBannerMini');
    if(b)b.classList.add('fadeOut');
    setTimeout(()=>{const x=document.getElementById('recordBannerMini'); if(x)x.remove();},550);
  },2200);
}
function autoCloseCelebration(data){
  setTimeout(()=>{
    const o=document.getElementById('celebrationOverlay');
    if(o){
      o.classList.add('fadeOut');
      setTimeout(()=>{closeCelebration(); showMiniRecordBanner(data);},600);
    }
  },3000);
}

function showRecordCelebration(data){
  const previous=data.previous ? `<div class="previousRecord"><div class="small">Previous Record</div><b>${esc(data.previousCar)}</b><br>${esc(data.previousValue)}</div>` : `<div class="previousRecord"><div class="small">First record for this event</div></div>`;
  const html=`<div id="celebrationOverlay" class="celebrationOverlay">
    <div class="celebrationCard">
      <div style="font-size:54px">🏆</div>
      <div class="recordTitle">${before?'RECORD SHATTERED!':'NEW EVENT RECORD!'}</div>
      <div class="small">${esc(data.eventName)}</div>
      <div class="recordCar">${esc(data.carName)}</div>
      <div class="recordTime">${esc(data.value)}</div>${data.improvement?`<div class="legacyCard">⚡ ${esc(data.improvement)}</div>`:'' }${data.heldText?`<div class="legacyCard">⏳ ${esc(data.heldText)}</div>`:'' }
      ${previous}
      <div class="grid">
        <button class="btn" onclick="closeCelebration();${data.continueAction}">▶️ ${data.nextEventName?`Start ${esc(data.nextEventName)}`:'Continue'}</button>
        <button class="btn secondary" onclick="closeCelebration();eventTab='leaderboard';renderEvent()">View Leaderboard</button>
      </div>
    </div>
  </div>`;
  document.body.insertAdjacentHTML('beforeend',html);
  playRecordSound();
  vibrateRecord();
  launchConfetti();
  autoCloseCelebration(data);
}
function closeCelebration(){
  const o=document.getElementById('celebrationOverlay');
  if(o)o.remove();
}


function safeShowRecordCelebration(payload){
  try{
    showRecordCelebration(payload);
  }catch(e){
    // fallback if any animation setting fails
    const title = payload.previous ? 'RECORD SHATTERED!' : 'NEW EVENT RECORD!';
    document.body.insertAdjacentHTML('beforeend', `<div id="celebrationOverlay" class="celebrationOverlay"><div class="celebrationCard"><div style="font-size:54px">🏆</div><div class="recordTitle">${title}</div><div class="recordCar">${esc(payload.carName)}</div><div class="recordTime">${esc(payload.value)}</div><button class="btn" onclick="closeCelebration();${payload.continueAction}">Continue</button></div></div>`); playRecordSound(); vibrateRecord(); launchConfetti(); autoCloseCelebration(payload);
  }
}

function saveResult(){
 const ev=eventById(currentEventId), carId=$('carSelect').value, value=parseResult(ev.id,$('resultInput').value);
 if(!carId||!isFinite(value)){toast('Enter a valid result');return;}
 const before=eventStats(ev.id).leader;
 const isRecord=!before || (isLong(ev.id)?value>before.value:value<before.value);
 const r={id:'r'+Date.now(),eventId:ev.id,carId,value,date:new Date().toISOString()};
 state.results.push(r);
 state.lastCarId=carId;
 state.currentCarId=carId;
 if(carIsComplete(carId)) state.currentCarId=null;
 save();
 const car=carById(carId);
 const nextEv=nextEventForCar(carId);
 const runStats=allPendingRuns();
 let actionButtons='';
 if(nextEv){
   actionButtons += `<button class="btn" onclick="directorNextEvent('${carId}','${nextEv.id}')">➡️ Next Event: ${esc(nextEv.name)}</button>`;
 } else {
   actionButtons += `<button class="btn" onclick="showCarComplete('${carId}')">🏁 Finish This Car</button>`;
 }
 actionButtons += `<button class="btn secondary" onclick="eventTab='leaderboard';renderEvent()">View Leaderboard</button>`;
 $('event').innerHTML=`<div class="card"><h2>Result Saved</h2>
 ${isRecord?`<div class="recordBox">🏆 ${before?'RECORD SHATTERED!':'NEW EVENT RECORD!'}<br>${esc(carName(car))}<br><span style="font-size:24px">${esc(fmt(ev.id,value))}</span>${before?`<br><span class="small">Previous: ${esc(fmt(ev.id,before.value))} — ${esc(carName(carById(before.carId)))}</span>`:''}</div>`:`<div class="resultBox">✅ Saved<br><b>${esc(carName(car))}</b><br>${esc(ev.name)} — ${esc(fmt(ev.id,value))}</div>`}
 <div class="resultBox"><b>${nextEv?'Same car continues':'Car complete'}</b><br><span class="small">${nextEv?`Next unfinished event for this car is ${esc(nextEv.name)}.`:'All 7 events complete for this car.'}</span></div>
 <div class="grid">${actionButtons}</div>
 <button class="btn secondary" onclick="openEvent('${ev.id}','waiting')">Back to Waiting</button>
 <p class="small">${runStats.remaining} total event runs remaining.</p></div>`;

 if(isRecord){
   const recordEntry=addRecordHistory(ev.id,carId,value,before);
   save();
   setTimeout(()=>safeShowRecordCelebration({
     eventName: ev.name,
     carName: carName(car),
     value: fmt(ev.id,value),
     previous: !!before,
     previousCar: before ? carName(carById(before.carId)) : '',
     previousValue: before ? fmt(ev.id,before.value) : '',
     improvement: recordEntry.improvement || '',
     heldText: recordEntry.daysStood!=null ? daysText(recordEntry.daysStood) : '',
     continueAction: nextEv ? `directorNextEvent('${carId}','${nextEv.id}')` : `showCarComplete('${carId}')`,
     nextEventName: nextEv ? nextEv.name : ''
   }),250);
 }

}

function editResult(id){const r=state.results.find(x=>x.id===id);if(!r)return;const raw=prompt('Edit result',fmt(r.eventId,r.value));if(raw===null)return;const v=parseResult(r.eventId,raw);if(!isFinite(v)){toast('Invalid result');return;}r.value=v;r.date=new Date().toISOString();save();toast('Result updated');renderEvent();}
function deleteResult(id){const r=state.results.find(x=>x.id===id);if(!r)return;if(!confirm('Delete this result?'))return;state.results=state.results.filter(x=>x.id!==id);save();toast('Deleted');renderEvent();}

function renderGarage(){
 const makes=['All',...Array.from(new Set(state.cars.map(c=>c.make))).sort()];
 let list=state.cars.filter(c=>(garageMake==='All'||c.make===garageMake)&&(!garageSearch||carName(c).toLowerCase().includes(garageSearch.toLowerCase())));
 const groups={};list.forEach(c=>(groups[c.make]??=[]).push(c));
 $('garage').innerHTML=`<div class="card"><h2>Garage</h2><p class="small">${state.cars.length} cars. Add new cars here.</p><label>Make</label><input id="newMake" placeholder="Lotus"><label>Model</label><input id="newModel" placeholder="Evija"><label>Year optional</label><input id="newYear" inputmode="numeric" placeholder="2020"><button class="btn" onclick="addCar()">Add Car</button><h3>Search</h3><input id="garageSearch" placeholder="Type search"><div class="grid"><button class="btn" onclick="garageSearch=$('garageSearch').value;renderGarage()">Search</button><button class="btn secondary" onclick="garageSearch='';garageMake='All';renderGarage()">Clear</button></div><div class="chips">${makes.map(m=>`<button class="chip ${m===garageMake?'on':''}" onclick="garageMake='${esc(m)}';renderGarage()">${esc(m)} ${m==='All'?'':state.cars.filter(c=>c.make===m).length}</button>`).join('')}</div>${Object.keys(groups).sort().map(m=>`<div class="makeGroup"><div class="makeHead"><b>${esc(m)}</b><span>${groups[m].length}</span></div>${groups[m].map(c=>`<div class="row"><div class="rank">🚗</div><div class="grow">${esc(carName(c))}</div><button class="chip" onclick="editCar('${c.id}')">Edit</button></div>`).join('')}</div>`).join('')||'<div class="empty">No cars found.</div>'}</div>`;
}
function addCar()

{
 const make=$('newMake').value.trim(), model=$('newModel').value.trim(), year=$('newYear').value.trim();
 if(!make||!model){toast('Enter make and model');return;}
 const name=`${make} ${model}${year?' '+year:''}`.replace(/\s+/g,' ').trim();
 const id=name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
 if(state.cars.some(c=>c.id===id||carName(c).toLowerCase()===name.toLowerCase())){toast('Car already exists');return;}
 state.cars.push({id,make,model,year,name});garageMake=make;garageSearch=model;save();toast('Car added');renderGarage();
}
function editCar(id){
 const car=carById(id);
 if(!car)return;

 const make=prompt('Manufacturer',car.make);
 if(make===null)return;

 const model=prompt('Model',car.model);
 if(model===null)return;

 const year=prompt('Year (leave blank if unknown)',car.year||'');
 if(year===null)return;

 const cleanMake=make.trim();
 const cleanModel=model.trim();
 const cleanYear=year.trim();

 if(!cleanMake||!cleanModel){
  toast('Manufacturer and model are required');
  return;
 }

 if(cleanYear&&!/^\d{4}$/.test(cleanYear)){
  toast('Year must be four digits');
  return;
 }

 const newName=`${cleanMake} ${cleanModel}${cleanYear?' '+cleanYear:''}`
  .replace(/\s+/g,' ')
  .trim();

 const duplicate=state.cars.some(c=>
  c.id!==id &&
  carName(c).toLowerCase()===newName.toLowerCase()
 );

 if(duplicate){
  toast('That car already exists');
  return;
 }

 car.make=cleanMake;
 car.model=cleanModel;
 car.year=cleanYear;
 car.name=newName;

 save();
 toast('Car updated');
 renderGarage();
}

function renderRecordHistory(){
 const hist=state.recordHistory||[];
 let content=`<div class="card"><h2>🏛️ Record History</h2><p class="small">Current records are shown even if the history entry was missed.</p>`;
 state.events.forEach(ev=>{
   let rows=hist.filter(h=>h.eventId===ev.id).slice().reverse();
   const boardRecord=eventStats(ev.id).leader;
   // Fallback: if a current leaderboard record exists but history is empty/missing, show it here.
   if(boardRecord && (!rows.length || rows[0].carId!==boardRecord.carId || Number(rows[0].value)!==Number(boardRecord.value))){
     rows.unshift({
       id:'fallback-'+ev.id,
       eventId:ev.id,
       carId:boardRecord.carId,
       value:boardRecord.value,
       date:boardRecord.date||new Date().toISOString(),
       fallback:true
     });
   }
   const current=rows[0];
   content += `<div class="legacyCard"><h3>🏁 ${esc(ev.name)}</h3>`;
   if(current){
     const stood=daysText(daysBetween(current.date,new Date().toISOString()));
     content += `<div class="legacyStat"><div><div class="legacyBig">${rows.length}</div><div class="small">record entries</div></div><div><div class="legacyBig">${stood.replace('Held for ','')||'today'}</div><div class="small">current record age</div></div></div>`;
   } else {
     content += `<div class="empty">No record yet.</div>`;
   }
   rows.forEach((h,i)=>{
     const car=carById(h.carId), prev=carById(h.previousCarId);
     content += `<div class="timelineItem ${i?'old':''}">
       <b>${i===0?'👑 Current Record':'⭐ Previous Record'}</b><br>
       ${esc(car?carName(car):h.carId)}<br>
       <span class="recordValue">${esc(fmt(h.eventId,h.value))}</span><br>
       <span class="small">${new Date(h.date).toLocaleDateString()}</span>
       ${h.fallback?`<br><span class="small">Current leaderboard record</span>`:''}
       ${h.improvement?`<br><span class="small">⚡ ${esc(h.improvement)}</span>`:''}
       ${h.daysStood!=null?`<br><span class="small">⏳ Previous record ${esc(daysText(h.daysStood).toLowerCase())}</span>`:''}
       ${prev?`<br><span class="small">Beat: ${esc(carName(prev))}</span>`:''}
     </div>`;
   });
   content += `</div>`;
 });
 content += `</div>`;
 $('more').innerHTML=content+`<div class="card"><button class="btn secondary" onclick="renderMore()">Back to More</button></div>`;
}

function renderMore(){
 const s=state.settings||{sound:true,confetti:true,vibrate:true};
 $('more').innerHTML=`<div class="card"><h2>More</h2>
 <button class="btn" onclick="renderRecordHistory()">🏛️ Record History</button>
 <h3>Celebrations</h3>
 <div class="resultBox">
   <label><input type="checkbox" id="setSound" ${s.sound?'checked':''}> 🔊 Celebration sounds</label>
   <label><input type="checkbox" id="setConfetti" ${s.confetti?'checked':''}> 🎉 Confetti</label>
   <label><input type="checkbox" id="setVibrate" ${s.vibrate?'checked':''}> 📳 Vibrate on new record</label>
   <button class="btn" onclick="saveSettings()">Save Settings</button>
   <button class="btn secondary" onclick="testCelebration()">Test Celebration</button>
 </div>
 <h3>Backup</h3>
 <button class="btn secondary" onclick="backup()">Copy Backup</button>
 <label>Restore backup</label><textarea id="restoreBox" rows="7"></textarea>
 <button class="btn" onclick="restore()">Restore</button>
 <button class="btn danger" onclick="clearResults()">Clear All Results</button></div>`;
}
function saveSettings(){
 state.settings={sound:$('setSound').checked,confetti:$('setConfetti').checked,vibrate:$('setVibrate').checked};
 save();
 toast('Settings saved');
}
function testCelebration(){
 saveSettings();
 showRecordCelebration({
   eventName:'Test Event',
   carName:'RaceHub Test Car',
   value:'09:24.766',
   previous:true,
   previousCar:'Previous Record Holder',
   previousValue:'09:25.114',
   continueAction:"closeCelebration()"
 });
}
function backup(){const txt=JSON.stringify(state);navigator.clipboard?.writeText(txt);toast('Backup copied if supported');}
function restore(){try{const raw=JSON.parse($('restoreBox').value);if(!raw.cars||!raw.events)throw Error();state=raw;save();toast('Restored');show('festival')}catch(e){toast('Invalid backup')}}
function clearResults(){if(!confirm('Clear all results? Cars will stay.'))return;state.results=[];state.lastRun=null;save();toast('Results cleared');show('festival')}

state=load();show('festival');
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(()=>{}));}
